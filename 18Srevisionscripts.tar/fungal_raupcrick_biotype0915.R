## Raup-Crick dissimilarity (vegan::raupcrick) between fungal genus-level
## SAMPLES, grouped by biotype (E vs K).
##
## This is the requested upgrade from fungal_community_homogeneity0914.R's
## Bray-Curtis PERMDISP: Bray-Curtis (and the PERMANOVA/PERMDISP built on it)
## can reject "one homogeneous community" just from uneven richness or
## sampling noise. Raup-Crick instead asks, for every pair of samples: if
## both were independent random draws of the OBSERVED per-sample richness
## from one shared regional genus pool (genera drawn in proportion to their
## observed occurrence frequency across all samples), how much genus overlap
## would we expect by chance? The index is the position of the OBSERVED
## overlap within that null distribution (999 simulated community pairs),
## so it already nets out the null of "same homogeneous pool, just noisily
## subsampled" -- rejecting it is stronger evidence of true compositional
## turnover than a Bray-Curtis-based test provides.
##
## Raup-Crick operates on presence/absence, not abundance -- so, unlike
## Bray-Curtis, it is not sensitive to how MUCH of a genus is present, only
## whether it is detected at all. Detection itself is still confounded by
## uneven sequencing depth (deeper samples find more rare genera), so the
## same rarefaction depth (25750) used throughout this project's other
## community-level tests is applied first, for the same reason.
##
## Usage: Rscript fungal_raupcrick_biotype0915.R [rarefy_depth]
## default rarefy_depth = 25750 (matches the project's QIIME2 convention).

suppressMessages(library(vegan))

args <- commandArgs(trailingOnly = TRUE)
rarefy_depth <- if (length(args) >= 1) as.numeric(args[1]) else 25750
set.seed(42)

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
tot <- colSums(counts)

dropped <- names(tot)[tot < rarefy_depth]
cat(sprintf("Rarefaction depth: %d\n", rarefy_depth))
cat(sprintf("Samples dropped (depth < %d): %d -- %s\n", rarefy_depth, length(dropped),
            paste(dropped, collapse = ", ")))

keep <- names(tot)[tot >= rarefy_depth]
mat <- t(counts[, keep])  # samples x taxa, required by vegan
mat_rare <- rrarefy(mat, sample = rarefy_depth)

biotype <- factor(substr(rownames(mat_rare), 1, 1))
cat(sprintf("\nSamples retained: %d (biotype E: %d, biotype K: %d)\n",
            nrow(mat_rare), sum(biotype == "E"), sum(biotype == "K")))

genus_richness <- rowSums(mat_rare > 0)
cat(sprintf("\nGenus richness per sample (post-rarefaction): mean %.1f, range %d-%d\n",
            mean(genus_richness), min(genus_richness), max(genus_richness)))

cat("\nComputing Raup-Crick dissimilarity (null model 'r1', 999 simulations -- this may take a moment)...\n")
rc <- raupcrick(mat_rare, null = "r1", nsimul = 999, chase = FALSE)

cat("\n--- PERMANOVA: does biotype explain Raup-Crick dissimilarity? (adonis2, 999 permutations) ---\n")
ad <- adonis2(rc ~ biotype, permutations = 999)
print(ad)

disp <- betadisper(rc, biotype, type = "median")
cat("\n--- PERMDISP: mean Raup-Crick distance-to-centroid per biotype ---\n")
print(tapply(disp$distances, biotype, mean))
cat("\n--- PERMDISP significance (permutest, 999 permutations) ---\n")
print(permutest(disp, permutations = 999))

cat("\nInterpretation: Raup-Crick ranges 0-1. Values near 0 mean a sample pair\n",
    "shares MORE genera than expected under random draws from one common\n",
    "pool (more similar than chance alone predicts); values near 1 mean a\n",
    "pair shares FEWER genera than expected (more dissimilar than chance --\n",
    "consistent with genuine compositional turnover between distinct\n",
    "communities, not just noisy subsampling of one homogeneous pool). A\n",
    "significant PERMANOVA here is stronger evidence for genuinely distinct\n",
    "biotype communities than the same result on raw Bray-Curtis, because\n",
    "the null expectation of a single shared pool is already subtracted out.\n",
    "A significant PERMDISP means one biotype's samples are less internally\n",
    "consistent (more scattered relative to their own centroid) than the\n",
    "other's, which can still confound the PERMANOVA result above.\n", sep = "")

out <- data.frame(sample = rownames(mat_rare), biotype = as.character(biotype),
                   genus_richness = genus_richness,
                   raupcrick_dist_to_centroid = disp$distances)
write.table(out, "fungal_raupcrick_biotype_distances.tsv", sep = "\t", quote = FALSE, row.names = FALSE)
cat("\nWritten: fungal_raupcrick_biotype_distances.tsv\n")
