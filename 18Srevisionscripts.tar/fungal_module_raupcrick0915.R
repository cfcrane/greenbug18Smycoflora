## Raup-Crick dissimilarity applied to the WGCNA module homogeneity test:
## the same genus-by-genus comparison as fungal_module_homogeneity0914.R,
## but replacing Bray-Curtis on raw abundance profiles with Raup-Crick on
## genus PRESENCE/ABSENCE across samples within a biotype.
##
## Raup-Crick's usual roles are transposed here relative to its standard
## ecological use. Normally "sites" are compared by which SPECIES they
## share, against a null pool built from species occurrence frequencies.
## Here "genera" play the role of the objects being compared (rows), and
## "samples" play the role of species incidence (columns) -- a genus's
## incidence vector is which samples it was detected in (count > 0 after
## rarefaction). The null model asks: if two genera occurred in as many
## samples as each was actually observed in, drawn at random according to
## how commonly samples in general carry ANY genus, how much sample-overlap
## would be expected by chance?
##   -- Raup-Crick near 0: the two genera co-occur across far MORE samples
##      than chance predicts (their incidence overlaps more than expected).
##   -- Raup-Crick near 1: they co-occur across far FEWER samples than
##      chance predicts (their occurrence is more mutually exclusive than
##      expected under a shared, randomly-distributed pool).
##
## Same caveat as fungal_module_homogeneity0914.R and as discussed
## explicitly: this stays entirely in GENUS space. A significant result
## says module-mate genera have non-random, module-structured patterns of
## WHICH SAMPLES they occur in, beyond what a shared pool of sample-level
## genus incidence would produce by chance. It says nothing about physical/
## spatial arrangement on the plant and nothing about shared ecological
## role or function.
##
## Same rarefaction depth (25750), grey-module exclusion, and
## Mortierella+Mortierellaceae merge-handling as fungal_module_homogeneity0914.R,
## for direct comparability with that Bray-Curtis result.

suppressMessages({ library(vegan) })

rarefy_depth <- 25750
set.seed(42)

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
tot <- colSums(counts)

run_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- grep(paste0("^", bt), colnames(counts), value = TRUE)
  ids <- ids[tot[ids] >= rarefy_depth]
  cat(sprintf("Samples retained (depth >= %d): %d of %d\n",
              rarefy_depth, length(ids), sum(grepl(paste0("^", bt), colnames(counts)))))

  mat <- t(counts[, ids])              # samples x taxa
  mat_rare <- rrarefy(mat, sample = rarefy_depth)

  mod <- read.delim(paste0("gb18Sfungwgcna_biotype", bt, "_modules.txt"), stringsAsFactors = FALSE)
  mod <- mod[mod$module != "grey", ]
  ## account for the Mortierella+Mortierellaceae merge used when building the WGCNA network
  if ("Mortierella+Mortierellaceae" %in% mod$genus && !("Mortierella+Mortierellaceae" %in% colnames(mat_rare))) {
    merged_col <- rowSums(mat_rare[, c("Mortierella", "Mortierellaceae"), drop = FALSE])
    mat_rare <- mat_rare[, !(colnames(mat_rare) %in% c("Mortierella", "Mortierellaceae"))]
    mat_rare <- cbind(mat_rare, "Mortierella+Mortierellaceae" = merged_col)
  }

  common_genera <- intersect(mod$genus, colnames(mat_rare))
  cat(sprintf("Module genera available in rarefied table: %d of %d\n", length(common_genera), nrow(mod)))

  taxon_mat <- t(mat_rare[, common_genera])   # genera x samples
  module <- factor(setNames(mod$module, mod$genus)[common_genera])

  cat("\nModule sizes used in this test:\n")
  print(table(module))

  incidence <- (taxon_mat > 0) * 1   # genera x samples presence/absence
  cat(sprintf("\nGenus incidence across samples: mean %.1f of %d samples occupied, range %d-%d\n",
              mean(rowSums(incidence)), ncol(incidence), min(rowSums(incidence)), max(rowSums(incidence))))

  cat("\nComputing Raup-Crick dissimilarity between genera (null model 'r1', 999 simulations)...\n")
  rc <- raupcrick(incidence, null = "r1", nsimul = 999, chase = FALSE)

  disp <- betadisper(rc, module, type = "median")
  cat("\n--- PERMDISP: mean Raup-Crick distance-to-module-centroid per module ---\n")
  print(tapply(disp$distances, module, mean))
  cat("\n--- PERMDISP significance (permutest, 999 permutations) ---\n")
  print(permutest(disp, permutations = 999))

  cat("\n--- PERMANOVA: are modules separated in genus Raup-Crick space? (adonis2, 999 permutations) ---\n")
  ad <- adonis2(rc ~ module, permutations = 999)
  print(ad)

  invisible(list(disp = disp, adonis = ad))
}

resE <- run_for_biotype("E")
resK <- run_for_biotype("K")
