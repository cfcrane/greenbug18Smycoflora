## Pearson, Spearman, and Kendall correlation between two taxa's relative
## abundance profiles across samples, from a genus-level (or other rank) count
## table structured like fung_genus_forbiom.txt: first column holds taxon
## names (header "#OTU ID"), remaining columns are per-sample counts.
##
## Each taxon's count in a sample is first converted to a fraction of that
## sample's total reads (i.e. the column sum across ALL taxa/rows in the
## file, so it reflects that sample's full library size, not just the two
## taxa of interest) before computing correlations.
##
## Usage:
##   Rscript taxoncorr0910.R <input_file> <taxon1> <taxon2>
## or edit the CONFIG block below and run with no arguments.

## ---- CONFIG (used only if no command-line args are given) ----
input_file <- "fung_genus_forbiom.txt"
taxon1     <- "Fungi"
taxon2     <- "Hannaella"
## -----------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) == 3) {
  input_file <- args[1]
  taxon1     <- args[2]
  taxon2     <- args[3]
}

d <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE)
names(d)[1] <- "taxon"

get_row <- function(taxon_name) {
  hit <- d[d$taxon == taxon_name, ]
  if (nrow(hit) == 0) stop("Taxon not found: ", taxon_name)
  if (nrow(hit) > 1) {
    warning(sprintf("Taxon '%s' matches %d rows; using the first match", taxon_name, nrow(hit)))
    hit <- hit[1, ]
  }
  as.numeric(hit[1, -1])
}

counts_x <- get_row(taxon1)
counts_y <- get_row(taxon2)

sample_totals <- colSums(d[, -1])
x <- counts_x / sample_totals
y <- counts_y / sample_totals

cat(sprintf("Taxon 1: %s (fraction of total reads)\nTaxon 2: %s (fraction of total reads)\nSamples:  %d\n\n",
            taxon1, taxon2, length(x)))

## exact = FALSE for spearman/kendall: these count tables commonly have tied
## values (e.g. repeated low counts, zeros), which makes R's default exact
## null distribution inapplicable and triggers a warning; the normal/t
## approximation used with exact = FALSE handles ties cleanly.
methods <- list(
  pearson  = list(exact = NA),
  spearman = list(exact = FALSE),
  kendall  = list(exact = FALSE)
)

for (m in names(methods)) {
  ct <- if (is.na(methods[[m]]$exact)) {
    cor.test(x, y, method = m)
  } else {
    cor.test(x, y, method = m, exact = methods[[m]]$exact)
  }
  est_name <- names(ct$estimate)
  cat(sprintf("%-8s: %s = %.4f   p = %.4g\n", m, est_name, unname(ct$estimate), ct$p.value))
}
