## Correlates each fungal genus's FRACTIONAL abundance against sampling day,
## using Pearson, Spearman, and Kendall correlation, computed across every
## individual biological replicate (not timepoint means).
##
## Input files:
##   gb18Sqfildeblurredseqs1119_combined_unitever10_99taxa.txt
##     -- "Feature ID", "Taxon" (d__;p__;c__;o__;f__;g__;s__), "Confidence".
##        Row 1 after the header is a QIIME2 "#q2:types" metadata line and
##        is skipped. Genus is taken from the "g__" field; features with no
##        genus-level assignment are dropped (they can't contribute to a
##        genus's fractional abundance).
##   gb18Sqfildeblurredcounts1119taxcounts.txt
##     -- "#OTU ID" (feature hash) x per-sample raw counts, first line is a
##        QIIME2 biom-export comment and is skipped.
##
## Sample ID structure (confirmed against the actual column headers, all
## 312 samples, and cross-checked against gb18Sshannonkwrawdata.txt's
## host_species/timepoint columns): [Biotype][Species][X]-[Timepoint][Replicate],
## e.g. "EW1-23" or "KW1-13" -- a 2-letter prefix (biotype E/K, then a HOST
## SPECIES letter: A=Aegilops_triuncialis, B=barley, R=rye, S=sorghum,
## W=wheat -- NOT a tissue/sample-type as originally assumed in this
## script), one digit whose meaning isn't needed here (constant within a
## replicate's time series, so likely a block/plant/cage identifier), a
## hyphen, then exactly two digits: the FIRST digit after the hyphen is the
## timepoint code, the second is a replicate index. Timepoint codes map to
## days as 0->day 0, 1->day 2, 2->day 4, 3->day 8 (confirmed against
## gb18Sshannonkwrawdata.txt's "t0"/"t2"/"t4"/"t8" timepoint field).
##
## ALL FIVE host species are pooled together here (per biotype), matching
## the convention already used throughout this project's other genus-level
## community analyses (WGCNA, PERMANOVA/PERMDISP, Raup-Crick, co-occurrence
## tests), which likewise group samples by biotype alone without splitting
## by host species. An earlier version of this script incorrectly
## restricted to species "W" (wheat) only -- that was wrong; every biotype
## group should include all five host species.
##
## CAVEAT specific to a time-correlation test (doesn't apply the same way
## to the non-time-based community tests this project also runs): day 0
## (t0) sampling exists ONLY for wheat -- the other four host species were
## first sampled at day 2. So "day" is partially confounded with host
## species at the day-0 end of the series specifically: any correlation
## driven by the day-0 samples is also, unavoidably, a wheat-vs-everything
## comparison at that single timepoint. Days 2/4/8 include all five
## species. The per-biotype console output below prints a day x
## host_species breakdown so this is visible rather than hidden.
##
## "Fractional abundance" = genus raw count / TOTAL raw reads for that
## sample (all features in the original count table, not just genus-
## resolved ones), i.e. relative to full sequencing depth -- the same
## fraction-of-total-reads convention used elsewhere in this project.
##
## Run separately per biotype (E, K), matching this project's standing
## convention that biotype is the primary structuring variable -- pooling
## biotypes would let systematic E-vs-K compositional differences
## contaminate a time correlation that has nothing to do with time itself.
##
## Genus prevalence filter (min_prev=3 samples with raw count>=10) matches
## the filter used throughout this project's other genus-level analyses
## (e.g. wgcna_fungal_bybiotype0713.R), applied here on the full,
## all-species, per-biotype raw genus count sub-matrix before correlation.
##
## Spearman and Kendall use exact=FALSE: day takes only 4 distinct values
## across dozens of replicates, guaranteeing heavy ties, so the exact null
## distribution doesn't apply (same convention already established in this
## project's other correlation scripts).
##
## Output is sorted by Spearman rho, descending (per user request), and
## Benjamini-Hochberg correction is applied to each method's p-values
## globally across all genera tested within that biotype.

taxonomy_file <- "gb18Sqfildeblurredseqs1119_combined_unitever10_99taxa.txt"
counts_file   <- "gb18Sqfildeblurredcounts1119taxcounts.txt"
metadata_file <- "gb18Sshannonkwrawdata.txt"
min_prev      <- 3
min_count     <- 10
timepoint_to_day <- c("0" = 0, "1" = 2, "2" = 4, "3" = 8)

## ---- Load taxonomy, extract genus ----
tax <- read.delim(taxonomy_file, check.names = FALSE, stringsAsFactors = FALSE)
tax <- tax[tax[["Feature ID"]] != "#q2:types", ]

has_genus <- grepl("g__", tax$Taxon)
genus_raw <- sub(".*(g__[^;]*).*", "\\1", tax$Taxon)
genus_raw[!has_genus] <- NA
tax$genus <- sub("^g__", "", genus_raw)
tax <- tax[!is.na(tax$genus) & tax$genus != "", ]
cat(sprintf("Features with genus-level assignment: %d\n", nrow(tax)))

## ---- Load counts, compute per-sample TOTAL depth before any filtering ----
counts <- read.delim(counts_file, check.names = FALSE, stringsAsFactors = FALSE,
                      comment.char = "", skip = 1)
names(counts)[1] <- "FeatureID"
sample_cols <- setdiff(names(counts), "FeatureID")
sample_total <- colSums(counts[, sample_cols])

## ---- Aggregate raw counts to genus level (all sample types, for now) ----
m <- match(counts$FeatureID, tax[["Feature ID"]])
counts_g <- counts[!is.na(m), ]
genus_of <- tax$genus[m[!is.na(m)]]
genus_counts <- rowsum(counts_g[, sample_cols], group = genus_of)
cat(sprintf("Genera after aggregation: %d\n", nrow(genus_counts)))

## ---- Parse sample IDs: biotype, host-species letter, timepoint code, day ----
id_parts <- regmatches(sample_cols, regexec("^([A-Z])([A-Z])[0-9]-([0-9])[0-9]$", sample_cols))
biotype  <- vapply(id_parts, `[`, character(1), 2)
tp_code  <- vapply(id_parts, `[`, character(1), 4)
day      <- unname(timepoint_to_day[tp_code])
names(biotype) <- names(tp_code) <- names(day) <- sample_cols

valid_ids <- sample_cols[!is.na(biotype)]
cat(sprintf("Samples matching expected ID pattern: %d of %d total\n", length(valid_ids), length(sample_cols)))

## ---- Load metadata for host_species (diagnostic day x species breakdown only) ----
meta_raw <- read.delim(metadata_file, check.names = FALSE, stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]   # drop QIIME2 "#q2:types" row
host_species <- setNames(meta_raw$host_species, meta_raw$id)

run_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- valid_ids[biotype[valid_ids] == bt]
  d <- day[ids]
  cat(sprintf("Samples: %d, day values present: %s\n", length(ids),
              paste(sort(unique(d)), collapse = ", ")))
  cat("Replicates per day:\n")
  print(table(d))
  cat("\nHost species x day breakdown (day 0 is wheat-only by design -- see header caveat):\n")
  print(table(host_species[ids], d))

  raw <- as.matrix(genus_counts[, ids])
  keep_genus <- rowSums(raw >= min_count) >= min_prev
  raw_f <- raw[keep_genus, , drop = FALSE]
  cat(sprintf("Genera retained after prevalence filter (>=%d samples with count>=%d): %d of %d\n",
              min_prev, min_count, nrow(raw_f), nrow(raw)))

  frac <- sweep(raw_f, 2, sample_total[ids], "/")

  res <- do.call(rbind, lapply(rownames(frac), function(g) {
    x <- frac[g, ]
    pear <- cor.test(x, d, method = "pearson")
    spear <- cor.test(x, d, method = "spearman", exact = FALSE)
    kend <- cor.test(x, d, method = "kendall", exact = FALSE)
    data.frame(genus = g,
               r_pearson = unname(pear$estimate), p_pearson = pear$p.value,
               rho_spearman = unname(spear$estimate), p_spearman = spear$p.value,
               tau_kendall = unname(kend$estimate), p_kendall = kend$p.value,
               stringsAsFactors = FALSE)
  }))

  res$q_pearson <- p.adjust(res$p_pearson, method = "BH")
  res$q_spearman <- p.adjust(res$p_spearman, method = "BH")
  res$q_kendall <- p.adjust(res$p_kendall, method = "BH")

  res <- res[order(-res$rho_spearman), ]

  cat(sprintf("\nSignificant (BH q<0.05): Pearson %d, Spearman %d, Kendall %d (of %d genera)\n",
              sum(res$q_pearson < 0.05), sum(res$q_spearman < 0.05), sum(res$q_kendall < 0.05), nrow(res)))

  cat("\n--- Top 10 genera by Spearman rho (most positively correlated with day) ---\n")
  print(head(res[, c("genus", "rho_spearman", "q_spearman", "r_pearson", "q_pearson")], 10), row.names = FALSE)
  cat("\n--- Bottom 10 genera by Spearman rho (most negatively correlated with day) ---\n")
  print(tail(res[, c("genus", "rho_spearman", "q_spearman", "r_pearson", "q_pearson")], 10), row.names = FALSE)

  fname <- paste0("fungal_genus_vs_time_biotype", bt, ".tsv")
  write.table(res, fname, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("\nWritten:", fname, "\n")

  invisible(res)
}

resE <- run_for_biotype("E")
resK <- run_for_biotype("K")
