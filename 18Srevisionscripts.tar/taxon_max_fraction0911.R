## For every taxon in a count table structured like fung_genus_forbiom.txt
## (first column = taxon name, header "#OTU ID"; remaining columns =
## per-sample counts), computes that taxon's fraction of total reads in each
## sample (count / sample's column sum across ALL taxa -- same normalization
## as taxoncorr0910.R), then finds the single largest such fraction across all
## samples for each taxon. Taxa are ranked descending by that maximum
## fraction.
##
## Also takes the top N taxa by that ranking and computes Spearman's rho for
## every pair among them (long-format table: taxon_a, taxon_b, rho), sorted
## descending by rho.
##
## Usage:
##   Rscript taxon_max_fraction0911.R <input_file> <N> [out_file] [corr_out_file]
## or edit the CONFIG block below and run with no arguments.

## ---- CONFIG (used only if no command-line args are given) ----
input_file    <- "fung_genus_forbiom_biotypeK.txt"
top_n         <- 10
out_file      <- NULL   # NULL -> auto-named from input_file
corr_out_file <- NULL   # NULL -> auto-named from input_file and top_n
## -----------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1) input_file    <- args[1]
if (length(args) >= 2) top_n         <- as.integer(args[2])
if (length(args) >= 3) out_file      <- args[3]
if (length(args) >= 4) corr_out_file <- args[4]

d <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE)
names(d)[1] <- "taxon"

sample_totals <- colSums(d[, -1])
frac <- sweep(as.matrix(d[, -1]), 2, sample_totals, "/")
rownames(frac) <- d$taxon

max_frac    <- apply(frac, 1, max)
max_sample  <- colnames(frac)[apply(frac, 1, which.max)]

out <- data.frame(taxon = d$taxon, max_fraction = max_frac, sample = max_sample,
                   stringsAsFactors = FALSE)
out <- out[order(-out$max_fraction), ]

if (is.null(out_file)) {
  out_file <- sub("\\.txt$", "_max_fraction.tsv", input_file)
  if (out_file == input_file) out_file <- paste0(input_file, "_max_fraction.tsv")
}
write.table(out, out_file, sep = "\t", quote = FALSE, row.names = FALSE)

cat(sprintf("Taxa ranked: %d   Samples: %d\n\n", nrow(out), ncol(frac)))
cat("Top 10 by maximum single-sample fraction:\n")
print(head(out, 10), row.names = FALSE)
cat("\nWritten:", out_file, "\n")

## ---- Spearman's rho (+ BH-adjusted q-values) for all pairs among the top N taxa ----
## q-values are BH-adjusted across exactly these C(N,2) pairwise tests -- the
## same family of top-N taxa the rho table is limited to -- not across all
## taxa in the full dataset.
top_taxa <- head(out$taxon, top_n)
top_mat  <- frac[top_taxa, , drop = FALSE]

pairs <- t(combn(top_taxa, 2))
## exact = FALSE: these fraction values commonly have ties (repeated low
## counts, zeros), which makes R's default exact null distribution
## inapplicable and triggers a warning; exact = FALSE uses the normal
## approximation instead, which handles ties cleanly.
tests <- apply(pairs, 1, function(p) {
  ct <- cor.test(top_mat[p[1], ], top_mat[p[2], ], method = "spearman", exact = FALSE)
  c(rho = unname(ct$estimate), p.value = ct$p.value)
})

corr_tbl <- data.frame(taxon_a = pairs[, 1], taxon_b = pairs[, 2],
                        rho = tests["rho", ], p.value = tests["p.value", ],
                        stringsAsFactors = FALSE)
corr_tbl$q.value <- p.adjust(corr_tbl$p.value, method = "BH")
corr_tbl <- corr_tbl[order(-corr_tbl$rho), ]

if (is.null(corr_out_file)) {
  corr_out_file <- sub("\\.txt$", sprintf("_top%d_spearman.tsv", top_n), input_file)
  if (corr_out_file == input_file) corr_out_file <- paste0(input_file, sprintf("_top%d_spearman.tsv", top_n))
}
write.table(corr_tbl, corr_out_file, sep = "\t", quote = FALSE, row.names = FALSE)

cat(sprintf("\nSpearman's rho for all %d pairs among the top %d taxa:\n", nrow(corr_tbl), top_n))
print(corr_tbl, row.names = FALSE)
cat("\nWritten:", corr_out_file, "\n")
