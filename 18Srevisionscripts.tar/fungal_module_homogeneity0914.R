## Tests whether the WGCNA modules found WITHIN one biotype represent
## genuinely distinct communities of co-varying genera, or could still be an
## arbitrary cut through one homogeneous group.
##
## Unlike the previous script (which compared SAMPLE groups on a
## sample-by-sample distance matrix), this one compares TAXON groups (WGCNA
## modules) on a GENUS-by-genus distance matrix: each genus's abundance
## profile across that biotype's samples defines its position, Bray-Curtis
## distance is computed between every pair of genera, and each genus's
## module color (from gb18Sfungwgcna_biotype{E,K}_modules.txt) is used as the
## grouping factor for:
##   (1) PERMDISP (betadisper + permutest) -- do modules differ in how
##       tightly clustered (dispersed) their member genera are around their
##       own module's centroid?
##   (2) PERMANOVA (adonis2) -- do modules occupy significantly different
##       locations in genus-distance space at all (i.e. are they actually
##       separated from each other, not just differently dispersed)?
## Both together answer "is there evidence of distinct communities": a
## significant PERMANOVA says modules ARE separated; a non-significant
## PERMDISP alongside it means that separation isn't just a dispersion
## artifact, so the PERMANOVA result can be trusted at face value.
##
## Same rarefaction depth (25750) and rationale as fungal_community_homogeneity0914.R,
## reused here for consistency and because Bray-Curtis distance (now between
## genera rather than between samples) is likewise sensitive to uneven
## per-sample sequencing depth.
##
## The grey module (WGCNA's catch-all for unassigned genera) is excluded, as
## in wgcna_fungal_kme0914.R -- it isn't a real community.

suppressMessages({ library(vegan) })

rarefy_depth <- 25750
set.seed(42)

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
tot <- colSums(counts)

run_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- grep(paste0("^", bt), colnames(counts), value = TRUE)
  ids <- ids[tot[ids] >= rarefy_depth]
  cat(sprintf("Samples retained (depth >= %d): %d of %d\n",
              rarefy_depth, length(ids), sum(grepl(paste0("^", bt), colnames(counts)))))

  mat <- t(counts[, ids])              # samples x taxa
  mat_rare <- rrarefy(mat, sample = rarefy_depth)

  mod <- read.delim(paste0("gb18Sfungwgcna_biotype", bt, "_modules.txt"), stringsAsFactors = FALSE)
  mod <- mod[mod$module != "grey", ]
  ## account for the Mortierella+Mortierellaceae merge used when building the WGCNA network
  if ("Mortierella+Mortierellaceae" %in% mod$genus && !("Mortierella+Mortierellaceae" %in% colnames(mat_rare))) {
    merged_col <- rowSums(mat_rare[, c("Mortierella", "Mortierellaceae"), drop = FALSE])
    mat_rare <- mat_rare[, !(colnames(mat_rare) %in% c("Mortierella", "Mortierellaceae"))]
    mat_rare <- cbind(mat_rare, "Mortierella+Mortierellaceae" = merged_col)
  }

  common_genera <- intersect(mod$genus, colnames(mat_rare))
  cat(sprintf("Module genera available in rarefied table: %d of %d\n", length(common_genera), nrow(mod)))

  taxon_mat <- t(mat_rare[, common_genera])   # genera x samples
  module <- factor(setNames(mod$module, mod$genus)[common_genera])

  cat("\nModule sizes used in this test:\n")
  print(table(module))

  bc <- vegdist(taxon_mat, method = "bray")

  disp <- betadisper(bc, module, type = "median")
  cat("\n--- PERMDISP: mean distance-to-module-centroid per module ---\n")
  print(tapply(disp$distances, module, mean))
  cat("\n--- PERMDISP significance (permutest, 999 permutations) ---\n")
  print(permutest(disp, permutations = 999))

  cat("\n--- PERMANOVA: are modules separated in genus-distance space? (adonis2, 999 permutations) ---\n")
  ad <- adonis2(bc ~ module, permutations = 999)
  print(ad)

  invisible(list(disp = disp, adonis = ad))
}

resE <- run_for_biotype("E")
resK <- run_for_biotype("K")
