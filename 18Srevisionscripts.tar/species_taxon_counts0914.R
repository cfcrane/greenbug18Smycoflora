## Returns total counts for a user-specified taxon AT THE SPECIES LEVEL,
## joining the deblurred feature count table with its QIIME2 taxonomy
## assignment.
##
## Input files:
##   gb18Sqfildeblurredcounts1119taxcounts.txt
##     -- "#OTU ID" (feature hash) x per-sample raw counts.
##   gb18Sqfildeblurredseqs1119_combined_unitever10_99taxa.txt
##     -- "Feature ID", "Taxon" (d__;p__;c__;o__;f__;g__;s__), "Confidence".
##        Row 1 after the header is a QIIME2 "#q2:types" metadata line and is
##        skipped. Not every feature is resolved to species -- 1209 of 16072
##        features in this table stop at genus (no "s__" level at all), and
##        those are correctly EXCLUDED from a species-level total (they are
##        not identified to the species being asked about).
##
## Species matching: case-insensitive, exact match against the "s__Genus_species"
## field (QIIME2/UNITE convention uses an underscore, not a space, between
## genus and species) -- so "Fusarium oxysporum", "Fusarium_oxysporum", and
## "fusarium OXYSPORUM" all match the same taxon. This is an exact match, not
## a substring search, so "Fusarium oxysporum" will not also pick up
## "Fusarium oxysporum f. sp. lycopersici" or similar extended epithets should
## any exist in this classifier's reference.
##
## Usage:
##   Rscript species_taxon_counts0914.R "<Genus species>" [counts_file] [taxonomy_file]
## or edit the CONFIG block below and run with no arguments.

## ---- CONFIG (used only if no command-line args are given) ----
species_name   <- "Fusarium oxysporum"
counts_file    <- "gb18Sqfildeblurredcounts1119taxcounts.txt"
taxonomy_file  <- "gb18Sqfildeblurredseqs1119_combined_unitever10_99taxa.txt"
## -----------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1) species_name  <- args[1]
if (length(args) >= 2) counts_file   <- args[2]
if (length(args) >= 3) taxonomy_file <- args[3]

species_norm <- gsub("\\s+", "_", trimws(species_name))

tax <- read.delim(taxonomy_file, check.names = FALSE, stringsAsFactors = FALSE)
tax <- tax[tax[["Feature ID"]] != "#q2:types", ]   # drop the QIIME2 type-metadata row

species_field <- sub(".*;\\s*s__", "", tax$Taxon)
has_species <- grepl("s__", tax$Taxon)
species_field[!has_species] <- NA

match_idx <- has_species & !is.na(species_field) & tolower(species_field) == tolower(species_norm)
matched_features <- tax[["Feature ID"]][match_idx]

cat(sprintf("Taxon queried: %s (matched as species field '%s')\n", species_name, species_norm))
cat(sprintf("Features matched at species level: %d\n", length(matched_features)))

if (length(matched_features) == 0) {
  stop(sprintf("No features assigned to species '%s' were found in %s.", species_name, taxonomy_file))
}

counts <- read.delim(counts_file, check.names = FALSE, stringsAsFactors = FALSE,
                      comment.char = "", skip = 1)
names(counts)[1] <- "FeatureID"

sub_counts <- counts[counts$FeatureID %in% matched_features, ]
cat(sprintf("Of those, %d found in the counts table (%d expected).\n",
            nrow(sub_counts), length(matched_features)))

sample_cols <- setdiff(names(sub_counts), "FeatureID")
per_sample_total <- colSums(sub_counts[, sample_cols, drop = FALSE])
grand_total <- sum(per_sample_total)

cat(sprintf("\nGrand total count for '%s' across all samples: %d\n", species_name, grand_total))

cat("\n--- Per-sample totals (nonzero samples) ---\n")
nz <- per_sample_total[per_sample_total > 0]
nz <- sort(nz, decreasing = TRUE)
print(nz)

cat(sprintf("\nSamples with nonzero counts: %d of %d\n", sum(per_sample_total > 0), length(per_sample_total)))

out_file <- sprintf("species_counts_%s.tsv", species_norm)
out_df <- data.frame(sample = names(per_sample_total), count = as.integer(per_sample_total))
out_df <- out_df[order(-out_df$count), ]
write.table(out_df, out_file, sep = "\t", quote = FALSE, row.names = FALSE)
cat("\nWritten:", out_file, "\n")
