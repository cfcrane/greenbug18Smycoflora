#!/usr/bin/env perl 
use warnings;
#This script simulates a cut -f x,y,z for multi-space delimited input files.
open (INP, "< $ARGV[0]"); #fungal_genus_vs_time_biotypeK_top12_3dp.txt
open (OUT, "> $ARGV[1]");
for ($i = 2; $i < scalar(@ARGV); $i++) {push(@fields, $ARGV[$i]);} #0, 3, 4, 8
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\s+/, $line);
  print OUT $vars[$fields[0]];
  for ($i = 1; $i < scalar(@fields); $i++) {print OUT "\t$vars[$fields[$i]]";}
  print OUT "\n";
}
