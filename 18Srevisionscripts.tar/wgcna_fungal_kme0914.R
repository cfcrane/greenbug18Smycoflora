## Reruns the fungal (18S) genus-level WGCNA pipeline exactly as in
## wgcna_fungal_bybiotype0713.R (same filtering, CLR transform, signed
## network, blockwiseModules parameters), which only ever saved genus->module
## COLOR assignments (gb18Sfungwgcna_biotype{E,K}_modules.txt) and never saved
## each genus's correlation to its module eigengene (kME). This script
## reproduces that pipeline and additionally computes kME per genus, then
## reports, per module, the fraction of member genera whose CLR abundance is
## NEGATIVELY correlated with their own module's eigengene.
##
## As a reproducibility check, module color assignments from this rerun are
## compared against the saved gb18Sfungwgcna_biotype{E,K}_modules.txt files
## before the kME results are trusted (blockwiseModules is deterministic
## given fixed input/power/parameters, so an exact match is expected).
##
## The grey module (WGCNA's catch-all for genera that didn't cluster into any
## real module) is excluded from the kME/negative-correlation summary, per
## standard convention -- it isn't a real co-abundance module.

suppressMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

merged <- colSums(counts[c("Mortierella", "Mortierellaceae"), ])
counts <- counts[!(rownames(counts) %in% c("Mortierella", "Mortierellaceae")), ]
counts <- rbind(counts, "Mortierella+Mortierellaceae" = merged)

meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE, stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
counts <- counts[, common_ids]
meta <- meta_raw[common_ids, ]
meta$biotype <- factor(meta$biotype)

filter_taxa <- function(mat, min_prev = 3, min_count = 10) {
  keep <- rowSums(mat >= min_count) >= min_prev
  mat[keep, , drop = FALSE]
}
clr_transform <- function(mat, pc = 0.5) {
  lg <- log(mat + pc)
  sweep(lg, 2, colMeans(lg), "-")
}

run_kme_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- rownames(meta)[meta$biotype == bt]
  mat <- counts[, ids]

  mat_f <- filter_taxa(mat, min_prev = 3, min_count = 10)
  clr <- clr_transform(mat_f, pc = 0.5)
  datExpr <- t(clr)

  gsg <- goodSamplesGenes(datExpr, verbose = 0)
  if (!gsg$allOK) datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]

  powers <- c(1:20)
  sft <- pickSoftThreshold(datExpr, powerVector = powers, networkType = "signed", verbose = 0)
  chosen_power <- sft$powerEstimate
  if (is.na(chosen_power)) {
    chosen_power <- sft$fitIndices$Power[which.max(sft$fitIndices[, "SFT.R.sq"])]
  }

  net <- blockwiseModules(datExpr, power = chosen_power, networkType = "signed",
                           TOMType = "signed", minModuleSize = 10,
                           mergeCutHeight = 0.25, numericLabels = TRUE,
                           saveTOMs = FALSE, verbose = 0)

  moduleColors <- labels2colors(net$colors)
  names(moduleColors) <- colnames(datExpr)

  ## ---- Reproducibility check against the saved modules.txt file ----
  saved_file <- paste0("gb18Sfungwgcna_biotype", bt, "_modules.txt")
  saved <- read.delim(saved_file, stringsAsFactors = FALSE)
  saved_map <- setNames(saved$module, saved$genus)
  common <- intersect(names(moduleColors), names(saved_map))
  mismatch <- sum(moduleColors[common] != saved_map[common])
  cat(sprintf("Reproducibility check vs %s: %d/%d genera match; %d mismatched; %d in rerun not in saved; %d in saved not in rerun\n",
              saved_file, sum(moduleColors[common] == saved_map[common]), length(common), mismatch,
              length(setdiff(names(moduleColors), names(saved_map))),
              length(setdiff(names(saved_map), names(moduleColors)))))

  ## ---- kME: correlation of each genus's CLR abundance with its OWN module's eigengene ----
  MEs <- net$MEs
  colnames(MEs) <- labels2colors(as.integer(sub("^ME", "", colnames(MEs))))

  kme_own <- vapply(seq_along(moduleColors), function(i) {
    g <- names(moduleColors)[i]
    m <- moduleColors[i]
    cor(datExpr[, g], MEs[[m]], use = "pairwise.complete.obs")
  }, numeric(1))
  names(kme_own) <- names(moduleColors)

  df <- data.frame(genus = names(moduleColors), module = moduleColors, kME = kme_own,
                    stringsAsFactors = FALSE)
  df_real <- df[df$module != "grey", ]

  summary_tbl <- do.call(rbind, lapply(split(df_real, df_real$module), function(d) {
    data.frame(module = d$module[1], n_genera = nrow(d),
               n_negative = sum(d$kME < 0),
               frac_negative = sum(d$kME < 0) / nrow(d))
  }))
  summary_tbl <- summary_tbl[order(-summary_tbl$frac_negative), ]

  cat("\nFraction of member genera NEGATIVELY correlated with their module's eigengene (grey excluded):\n")
  print(summary_tbl, row.names = FALSE)

  flagged <- summary_tbl[summary_tbl$frac_negative > 0.10, ]
  if (nrow(flagged) > 0) {
    cat("\n*** Module(s) with >10% negatively-correlated member genera: ***\n")
    print(flagged, row.names = FALSE)
  } else {
    cat("\nNo module exceeded 10% negatively-correlated member genera.\n")
  }

  fname <- paste0("gb18Sfungwgcna_biotype", bt, "_kME.tsv")
  write.table(df, fname, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("\nWritten:", fname, "\n")

  invisible(list(df = df, summary = summary_tbl))
}

resE <- run_kme_for_biotype("E")
resK <- run_kme_for_biotype("K")
