## Screens all pairwise WGCNA modules for possible antagonism: for every pair
## of modules (A, B), correlates every taxon in A against every taxon in B
## (relative abundance, i.e. fraction of each sample's total reads -- same
## normalization as taxoncorr0910.R / taxoncorr_all0910.R), BH-adjusts the
## p-values, and reports how many/what fraction of cross-module taxon pairs
## are significantly positively correlated, significantly negatively
## correlated, or non-significant.
##
## Rationale for counting negative correlations as candidate "antagonism":
## a taxon pair whose relative abundances move in consistently opposite
## directions across samples is *consistent with* competitive exclusion or
## other antagonistic interaction, though correlation alone cannot establish
## causality -- this script only screens/quantifies the pattern.
##
## Multiple-testing note: BH adjustment is applied ONCE, globally, across
## every cross-module taxon-pair test run in the whole analysis (i.e. the
## true family of simultaneous hypotheses being tested), not separately
## within each module pair. Significance counts/fractions per module pair are
## then tabulated using those globally-adjusted q-values.
##
## The WGCNA "grey" module (the standard catch-all for taxa that did not
## cluster into any real module) is excluded by default -- see
## exclude_grey below.
##
## Input file formats:
##   count_file:  first column = taxon name (header "#OTU ID"), remaining
##                columns = per-sample counts -- e.g. fung_genus_forbiom_biotypeK.txt
##   module_file: two columns, "genus" and "module" (module = WGCNA color
##                label) -- e.g. gb18Sfungwgcna_biotypeK_modules.txt
##
## Usage:
##   Rscript wgcna_module_antagonism0910.R <count_file> <module_file> <method> [alpha] [out_file]
## or edit the CONFIG block below and run with no arguments.

## ---- CONFIG (used only if no command-line args are given) ----
count_file   <- "fung_genus_forbiom_biotypeK.txt"
module_file  <- "gb18Sfungwgcna_biotypeK_modules.txt"
method       <- "spearman"   # "pearson", "spearman", or "kendall"
alpha        <- 0.05
exclude_grey <- TRUE
out_file     <- NULL         # NULL -> auto-named from method; the taxon-pair
                              # detail file is this name with "_taxonpairs"
                              # inserted before the .tsv extension
## -----------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 3) {
  count_file  <- args[1]
  module_file <- args[2]
  method      <- args[3]
  if (length(args) >= 4) alpha    <- as.numeric(args[4])
  if (length(args) >= 5) out_file <- args[5]
}
method <- tolower(method)
if (!method %in% c("pearson", "spearman", "kendall")) {
  stop("method must be one of: pearson, spearman, kendall (got '", method, "')")
}

## ---- Load and prep abundance data (fraction of each sample's total reads) ----
d <- read.delim(count_file, check.names = FALSE, stringsAsFactors = FALSE)
names(d)[1] <- "taxon"
sample_totals <- colSums(d[, -1])
frac <- sweep(as.matrix(d[, -1]), 2, sample_totals, "/")
rownames(frac) <- d$taxon

## ---- Load module assignments ----
mod <- read.delim(module_file, stringsAsFactors = FALSE)
names(mod)[1:2] <- c("taxon", "module")
if (exclude_grey) mod <- mod[mod$module != "grey", ]

## WGCNA merges pairs of near-identical-profile taxa into one "GenusA+GenusB"
## row; split these back into separate genera, each kept in the module the
## merged row was assigned to, so they're treated as two ordinary taxa.
is_merged <- grepl("+", mod$taxon, fixed = TRUE)
if (any(is_merged)) {
  split_rows <- do.call(rbind, lapply(which(is_merged), function(i) {
    genera <- trimws(strsplit(mod$taxon[i], "+", fixed = TRUE)[[1]])
    data.frame(taxon = genera, module = mod$module[i], stringsAsFactors = FALSE)
  }))
  cat(sprintf("Split %d merged '+'-joined taxon name(s) into %d separate genera:\n",
              sum(is_merged), nrow(split_rows)))
  print(data.frame(merged = mod$taxon[is_merged], module = mod$module[is_merged]), row.names = FALSE)
  mod <- rbind(mod[!is_merged, ], split_rows)
}

missing_taxa <- setdiff(mod$taxon, rownames(frac))
if (length(missing_taxa) > 0) {
  warning(sprintf("%d taxon/taxa in module file not found in count file (skipped): %s",
                   length(missing_taxa), paste(missing_taxa, collapse = ", ")))
  mod <- mod[!(mod$taxon %in% missing_taxa), ]
}

modules <- sort(unique(mod$module))
cat(sprintf("Modules (excluding grey: %s): %s\n", exclude_grey, paste(modules, collapse = ", ")))
for (mname in modules) {
  cat(sprintf("  %-12s %d taxa\n", mname, sum(mod$module == mname)))
}
cat(sprintf("\nMethod: %s   alpha (for q-value significance): %.3f\n\n", method, alpha))

## ---- Correlate every taxon pair across every module pair ----
## exact = FALSE for spearman/kendall: these tables commonly have tied values
## (repeated low counts, zeros), which makes R's default exact null
## distribution inapplicable and triggers a warning; exact = FALSE uses the
## normal/t approximation instead, which handles ties cleanly.
cor_one <- function(x, y) {
  ct <- tryCatch(
    if (method == "pearson") cor.test(x, y, method = method)
    else cor.test(x, y, method = method, exact = FALSE),
    error = function(e) NULL
  )
  if (is.null(ct)) return(c(estimate = NA_real_, p.value = NA_real_))
  c(estimate = unname(ct$estimate), p.value = ct$p.value)
}

module_pairs <- combn(modules, 2, simplify = FALSE)

all_tests <- do.call(rbind, lapply(module_pairs, function(pr) {
  taxa_a <- mod$taxon[mod$module == pr[1]]
  taxa_b <- mod$taxon[mod$module == pr[2]]
  grid   <- expand.grid(taxon_a = taxa_a, taxon_b = taxa_b, stringsAsFactors = FALSE)
  res <- t(vapply(seq_len(nrow(grid)), function(i) {
    cor_one(frac[grid$taxon_a[i], ], frac[grid$taxon_b[i], ])
  }, numeric(2)))
  data.frame(module_a = pr[1], module_b = pr[2],
             taxon_a = grid$taxon_a, taxon_b = grid$taxon_b,
             estimate = res[, "estimate"], p.value = res[, "p.value"],
             stringsAsFactors = FALSE)
}))

all_tests$q.value <- p.adjust(all_tests$p.value, method = "BH")

## ---- Summarize per module pair ----
summarize_pair <- function(sub) {
  n_total <- nrow(sub)
  is_sig  <- !is.na(sub$q.value) & sub$q.value <= alpha
  n_pos   <- sum(is_sig & sub$estimate > 0)
  n_neg   <- sum(is_sig & sub$estimate < 0)
  n_nonsig <- n_total - n_pos - n_neg
  c(n_pairs = n_total, n_pos = n_pos, n_neg = n_neg, n_nonsig = n_nonsig,
    frac_pos = n_pos / n_total, frac_neg = n_neg / n_total, frac_nonsig = n_nonsig / n_total)
}

summary_tbl <- do.call(rbind, lapply(module_pairs, function(pr) {
  sub <- all_tests[all_tests$module_a == pr[1] & all_tests$module_b == pr[2], ]
  data.frame(module_a = pr[1], module_b = pr[2],
             n_taxa_a = length(unique(sub$taxon_a)), n_taxa_b = length(unique(sub$taxon_b)),
             t(summarize_pair(sub)), stringsAsFactors = FALSE)
}))

summary_tbl <- summary_tbl[order(-summary_tbl$frac_neg), ]

if (is.null(out_file)) out_file <- sprintf("wgcna_module_antagonism_%s.tsv", method)
write.table(summary_tbl, out_file, sep = "\t", quote = FALSE, row.names = FALSE)

## Derive the taxon-pair detail filename from out_file (insert "_taxonpairs"
## before the extension, or append it if out_file has no .tsv/.txt extension).
if (grepl("\\.(tsv|txt)$", out_file, ignore.case = TRUE)) {
  pairs_out <- sub("\\.(tsv|txt)$", "_taxonpairs.\\1", out_file, ignore.case = TRUE)
} else {
  pairs_out <- paste0(out_file, "_taxonpairs.tsv")
}
write.table(all_tests[order(all_tests$q.value), ], pairs_out, sep = "\t", quote = FALSE, row.names = FALSE)

cat("Module-pair summary (sorted by fraction of significantly NEGATIVE correlations, descending):\n")
print(summary_tbl, row.names = FALSE)
cat("\nWritten:", out_file, "\n")
cat("Written (full taxon-pair-level detail):", pairs_out, "\n")
