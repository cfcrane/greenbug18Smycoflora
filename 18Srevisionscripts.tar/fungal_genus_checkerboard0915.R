## Checkerboard score (C-score) null-model test (Stone & Roberts 1990,
## Oecologia, building on Diamond 1975's checkerboard concept), applied to
## the same WGCNA module genera as fungal_genus_veech_cooccur0915.R.
##
## Unlike the Veech pairwise test, this is a WHOLE-ASSEMBLAGE statistic:
## the C-score counts, summed over every genus pair, the number of
## "checkerboard units" (samples where genus i is present and genus j
## absent, plus samples where the reverse holds) -- a high C-score means
## the assemblage as a whole shows more mutually-exclusive occurrence
## patterns than a null model predicts. vegan::oecosimu() supplies the
## null distribution by simulating many random community matrices under a
## null model and asks whether the OBSERVED C-score is an outlier relative
## to that simulated null distribution.
##
## Null model: "quasiswap" (fixed-fixed: preserves each genus's occurrence
## frequency AND each sample's genus richness exactly, only permuting which
## specific genera occur together). This is the null-model algorithm
## recommended by Gotelli (2000, Ecology) and subsequent work as the best
## controlled for Type I/II error in checkerboard/co-occurrence null model
## testing, and is the same standard used across most published
## applications of the C-score.
##
## Same genus set, rarefaction depth (25750), grey-module exclusion, and
## Mortierella+Mortierellaceae merge-handling as the Veech test, for
## direct comparability.

suppressMessages(library(vegan))

rarefy_depth <- 25750
set.seed(42)
nsimul <- 999

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
tot <- colSums(counts)

run_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- grep(paste0("^", bt), colnames(counts), value = TRUE)
  ids <- ids[tot[ids] >= rarefy_depth]

  mat <- t(counts[, ids])
  mat_rare <- rrarefy(mat, sample = rarefy_depth)

  mod <- read.delim(paste0("gb18Sfungwgcna_biotype", bt, "_modules.txt"), stringsAsFactors = FALSE)
  mod <- mod[mod$module != "grey", ]
  if ("Mortierella+Mortierellaceae" %in% mod$genus && !("Mortierella+Mortierellaceae" %in% colnames(mat_rare))) {
    merged_col <- rowSums(mat_rare[, c("Mortierella", "Mortierellaceae"), drop = FALSE])
    mat_rare <- mat_rare[, !(colnames(mat_rare) %in% c("Mortierella", "Mortierellaceae"))]
    mat_rare <- cbind(mat_rare, "Mortierella+Mortierellaceae" = merged_col)
  }

  common_genera <- intersect(mod$genus, colnames(mat_rare))

  ## vegan convention: sites (samples) as rows, species (genera) as columns
  comm <- (mat_rare[, common_genera] > 0) * 1
  cat(sprintf("Genera: %d, samples: %d\n", ncol(comm), nrow(comm)))

  cat(sprintf("\nRunning oecosimu with 'quasiswap' null model (%d simulations, whole assemblage)...\n", nsimul))
  oe_all <- oecosimu(comm, nestedchecker, method = "quasiswap", nsimul = nsimul)
  cat("\n--- Whole-assemblage C-score / checkerboard units, ALL module genera pooled ---\n")
  print(oe_all)

  ## Restrict to WITHIN-module structure: run separately per module, so the
  ## whole-assemblage test isn't dominated by the (expected, already
  ## established) within-module positive co-occurrence signal, and to see
  ## whether any individual module shows internal segregation.
  module_map <- setNames(mod$module, mod$genus)[common_genera]
  cat("\n--- Per-module checkerboard test (genera within that module only) ---\n")
  for (m in levels(factor(module_map))) {
    gs <- names(module_map)[module_map == m]
    if (length(gs) < 3) { cat(sprintf("\nModule %s: only %d genera, skipped.\n", m, length(gs))); next }
    sub_comm <- comm[, gs, drop = FALSE]
    oe_m <- oecosimu(sub_comm, nestedchecker, method = "quasiswap", nsimul = nsimul)
    cat(sprintf("\nModule %s (%d genera):\n", m, length(gs)))
    print(oe_m)
  }

  ## Between-module comparison: genera drawn from DIFFERENT modules only,
  ## which is the subset most directly relevant to the antagonism
  ## hypothesis (do genera from different modules show more checkerboard
  ## structure among themselves than the whole assemblage does).
  invisible(list(oe_all = oe_all))
}

resE <- run_for_biotype("E")
resK <- run_for_biotype("K")
