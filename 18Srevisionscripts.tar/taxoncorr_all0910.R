## Correlates ONE target taxon's relative-abundance profile against every
## other taxon in a count table structured like fung_genus_forbiom.txt (first
## column = taxon name, header "#OTU ID"; remaining columns = per-sample
## counts). Companion script to taxoncorr0910.R (which compares exactly two
## named taxa) -- this one runs the same fraction-of-total-reads + BH-adjusted
## correlation approach against all taxa at once, for screening.
##
## Each taxon's count in a sample is converted to a fraction of that sample's
## total reads (column sum across ALL taxa/rows) before computing
## correlations, exactly as in taxoncorr0910.R.
##
## Usage:
##   Rscript taxoncorr_all0910.R <input_file> <target_taxon> <method>
## <method> is one of: pearson, spearman, kendall -- the output is sorted in
## descending order of that method's correlation estimate. p-values from all
## three methods are still reported for every taxon; only the sort order and
## q-value (BH-adjusted p) are tied to the chosen method.
## or edit the CONFIG block below and run with no arguments.

## ---- CONFIG (used only if no command-line args are given) ----
input_file   <- "fung_genus_forbiom.txt"
target_taxon <- "Fungi"
method       <- "spearman"   # "pearson", "spearman", or "kendall"
out_file     <- NULL         # NULL -> auto-named from target_taxon + method
## -----------------------------------------------------------

args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 3) {
  input_file   <- args[1]
  target_taxon <- args[2]
  method       <- args[3]
}
method <- tolower(method)
if (!method %in% c("pearson", "spearman", "kendall")) {
  stop("method must be one of: pearson, spearman, kendall (got '", method, "')")
}

d <- read.delim(input_file, check.names = FALSE, stringsAsFactors = FALSE)
names(d)[1] <- "taxon"

target_hit <- which(d$taxon == target_taxon)
if (length(target_hit) == 0) stop("Target taxon not found: ", target_taxon)
if (length(target_hit) > 1) {
  warning(sprintf("Target taxon '%s' matches %d rows; using the first match", target_taxon, length(target_hit)))
  target_hit <- target_hit[1]
}

sample_totals <- colSums(d[, -1])
frac <- sweep(as.matrix(d[, -1]), 2, sample_totals, "/")

target_vec <- frac[target_hit, ]
other_idx  <- setdiff(seq_len(nrow(d)), target_hit)

## exact = FALSE for spearman/kendall: these tables commonly have tied values
## (repeated low counts, zeros), which makes R's default exact null
## distribution inapplicable and triggers a warning; exact = FALSE uses the
## normal/t approximation instead, which handles ties cleanly.
cor_one <- function(y, m) {
  ct <- tryCatch(
    if (m == "pearson") cor.test(target_vec, y, method = m)
    else cor.test(target_vec, y, method = m, exact = FALSE),
    error = function(e) NULL
  )
  if (is.null(ct)) return(c(estimate = NA_real_, p.value = NA_real_))
  c(estimate = unname(ct$estimate), p.value = ct$p.value)
}

res <- t(vapply(other_idx, function(i) cor_one(frac[i, ], method), numeric(2)))

out <- data.frame(
  taxon     = d$taxon[other_idx],
  estimate  = res[, "estimate"],
  p.value   = res[, "p.value"],
  stringsAsFactors = FALSE
)
out$q.value <- p.adjust(out$p.value, method = "BH")

out <- out[order(-out$estimate), ]
names(out)[names(out) == "estimate"] <- paste0(method, "_estimate")

if (is.null(out_file)) {
  out_file <- sprintf("taxoncorr_all_%s_%s.tsv", gsub("[^A-Za-z0-9]+", "_", target_taxon), method)
}
write.table(out, out_file, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")

cat(sprintf("Target taxon: %s\nMethod:       %s\nOther taxa:   %d\nDropped (NA, e.g. zero-variance rows): %d\n\n",
            target_taxon, method, nrow(out), sum(is.na(out[[paste0(method, "_estimate")]]))))
cat("Top 10 by", method, "estimate:\n")
print(head(out, 10), row.names = FALSE)
cat("\nWritten:", out_file, "\n")
