## Tests community homogeneity (homogeneity of multivariate dispersion,
## PERMDISP: vegan::betadisper + permutest) between biotype E and biotype K
## for the fungal 18S genus-level community, on Bray-Curtis distances.
##
## Rarefaction: sample read depths in fung_genus_forbiom.txt range from
## 14,733 to 841,189 (~57-fold difference; n=312 samples). Bray-Curtis
## dissimilarity (unlike some other metrics) IS sensitive to uneven
## sequencing depth, so distances/dispersion computed on raw counts would be
## confounded by depth differences between samples rather than reflecting
## true community (dis)similarity. This project's own QIIME2 pipeline
## (qiimecommandsNovDec2025.txt) already established a rarefaction depth of
## 25750 for exactly this reason (core-metrics-phylogenetic, Bray-Curtis
## included) -- reused here for consistency. At that depth, only ONE sample
## (EW1-23, depth 14733) falls below threshold and is dropped; every other
## sample (min remaining depth 25765) is rarefied down to 25750.
##
## Usage: Rscript fungal_community_homogeneity0914.R [rarefy_depth]
## default rarefy_depth = 25750 (matches the project's QIIME2 convention).

suppressMessages(library(vegan))

args <- commandArgs(trailingOnly = TRUE)
rarefy_depth <- if (length(args) >= 1) as.numeric(args[1]) else 25750
set.seed(42)

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
tot <- colSums(counts)

dropped <- names(tot)[tot < rarefy_depth]
cat(sprintf("Rarefaction depth: %d\n", rarefy_depth))
cat(sprintf("Samples dropped (depth < %d): %d -- %s\n", rarefy_depth, length(dropped),
            paste(dropped, collapse = ", ")))

keep <- names(tot)[tot >= rarefy_depth]
mat <- t(counts[, keep])  # samples x taxa, required by vegan

mat_rare <- rrarefy(mat, sample = rarefy_depth)

biotype <- factor(substr(rownames(mat_rare), 1, 1))
cat(sprintf("\nSamples retained: %d (biotype E: %d, biotype K: %d)\n",
            nrow(mat_rare), sum(biotype == "E"), sum(biotype == "K")))

bc <- vegdist(mat_rare, method = "bray")

disp <- betadisper(bc, biotype, type = "median")
cat("\n--- betadisper: mean distance-to-centroid (median) per group ---\n")
print(tapply(disp$distances, biotype, mean))

cat("\n--- PERMDISP significance test (permutest, 999 permutations) ---\n")
pt <- permutest(disp, permutations = 999)
print(pt)

cat("\n--- ANOVA on betadisper distances (parametric alternative) ---\n")
print(anova(disp))

cat("\nInterpretation: a NON-significant PERMDISP result means the two biotypes'\n",
    "within-group dispersion (spread) is statistically indistinguishable --\n",
    "consistent with (though not proof of) one homogeneous community structure\n",
    "shared across biotypes. A SIGNIFICANT result means one biotype's community\n",
    "is more heterogeneous (more variable) than the other's, which can itself\n",
    "confound a PERMANOVA test of the biotype effect on composition.\n", sep = "")
