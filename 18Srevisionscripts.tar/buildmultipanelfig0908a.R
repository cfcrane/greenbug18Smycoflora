## Vector-preserving multipanel composite: assembles PDF/SVG panels into one
## figure WITHOUT rasterizing them. Panels stay true vector (selectable text,
## editable paths) in the saved PDF and SVG; only the PNG copy is a raster.
##
## How it works: PDF panels are converted to SVG with poppler's `pdftocairo`
## (must be on PATH -- macOS: `brew install poppler`), then imported as real
## grid graphics via grImport2::readPicture()/pictureGrob(). Each panel is
## placed in a grid viewport cell, and the same grob tree is drawn directly
## into pdf(), svg(), and png() devices -- so the vector devices never touch
## a rasterized intermediate.
##
## IMPORTANT input-format note (this reverses the general SVG-vs-PDF advice
## for the raster-composite script, multipanel_figure0716.R): grImport2 only
## understands SVG produced by a Cairo-family renderer. Files from R's
## `svglite` device (what ggsave(..., "svg") uses, e.g. the companion .svg
## files next to these .pdf panels) are NOT compatible and will error on
## color parsing. Always point this script at the .pdf panel files -- they
## get converted to Cairo-compatible SVG internally via pdftocairo.
##
## Layout: 2 columns, filled row-major in the order panels are listed:
##   1 -> upper left     2 -> upper right
##   3 -> center left    4 -> center right
##   5 -> lower left     6 -> lower right
## Accepts 4-6 panel files.

## ---- CONFIG ----
panel_list_file  <- "filelist09082026a.txt"   # one panel .pdf path per line, in panel order
out_prefix       <- "gb18Sfig4_0908"
cell_width_in    <- 5      # inches, width of each grid cell in the composite
cell_height_in   <- 4.2    # inches, height of each grid cell (~ matches 288x234pt panels)
pdftocairo_bin   <- "pdftocairo"  # from poppler; macOS: brew install poppler
panel_labels     <- LETTERS   # A, B, C, ... one per panel, in panel order
label_fontsize   <- 16
label_inset      <- 0.03  # npc fraction from the cell's top-left corner
## -----------------

pkgs <- c("grImport2")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
library(grImport2)
library(grid)

if (Sys.which(pdftocairo_bin) == "") {
  stop("`", pdftocairo_bin, "` not found on PATH. Install poppler (e.g. `brew install poppler` ",
       "on macOS, or your Linux package manager's `poppler-utils`) to convert PDF panels to SVG.")
}

panel_files <- trimws(readLines(panel_list_file))
panel_files <- panel_files[nchar(panel_files) > 0]

if (length(panel_files) < 4 || length(panel_files) > 6) {
  stop(sprintf("Expected 4-6 panel files in %s, found %d", panel_list_file, length(panel_files)))
}
missing <- panel_files[!file.exists(panel_files)]
if (length(missing) > 0) stop("Panel file(s) not found: ", paste(missing, collapse = ", "))

## Convert each panel to a Cairo-family SVG (grImport2's actual requirement)
tmp_dir <- tempfile("panels_svg_")
dir.create(tmp_dir)

to_svg <- function(path) {
  ext <- tolower(tools::file_ext(path))
  if (ext == "pdf") {
    svg_path <- file.path(tmp_dir, paste0(tools::file_path_sans_ext(basename(path)), ".svg"))
    status <- system2(pdftocairo_bin, c("-svg", shQuote(path), shQuote(svg_path)))
    if (status != 0 || !file.exists(svg_path)) stop("pdftocairo failed converting: ", path)
    svg_path
  } else if (ext == "svg") {
    path  # assumed already Cairo-family SVG; svglite output will error in readPicture()
  } else {
    stop("Unsupported panel format for vector import: ", path, " (expected .pdf or .svg)")
  }
}

cat(sprintf("Reading %d panels (vector import via grImport2)...\n", length(panel_files)))
svg_paths <- vapply(panel_files, to_svg, character(1))
pics <- lapply(svg_paths, readPicture)

n <- length(pics)
ncol_grid <- 2
nrow_grid <- ceiling(n / ncol_grid)

draw_composite <- function() {
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(nrow_grid, ncol_grid)))
  for (k in seq_along(pics)) {
    row <- ((k - 1) %/% ncol_grid) + 1
    col <- ((k - 1) %% ncol_grid) + 1
    pushViewport(viewport(layout.pos.row = row, layout.pos.col = col))
    grid.draw(pictureGrob(pics[[k]], x = 0.5, y = 0.5, width = 1, height = 1,
                           default.units = "npc", distort = FALSE, expansion = 0))
    grid.text(panel_labels[k], x = label_inset, y = 1 - label_inset,
              just = c("left", "top"), gp = gpar(fontface = "bold", fontsize = label_fontsize))
    upViewport()
  }
  upViewport()
}

fig_width  <- cell_width_in * ncol_grid
fig_height <- cell_height_in * nrow_grid

pdf(paste0(out_prefix, ".pdf"), width = fig_width, height = fig_height)
draw_composite()
dev.off()

svg(paste0(out_prefix, ".svg"), width = fig_width, height = fig_height)
draw_composite()
dev.off()

png(paste0(out_prefix, ".png"), width = fig_width, height = fig_height, units = "in", res = 600)
draw_composite()
dev.off()

unlink(tmp_dir, recursive = TRUE)

cat(sprintf("\nWritten: %s.{pdf,svg,png}\n", out_prefix))
