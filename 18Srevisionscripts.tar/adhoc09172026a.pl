#!/usr/bin/env perl
use warnings;
#This script just rounds numbers in its input.
open (INP, "< $ARGV[0]");
open (OUT, "> $ARGV[1]");
$line = <INP>;
print OUT $line; #Print the header.
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  print OUT $vars[0];
  for ($i = 1; $i < scalar(@vars); $i++) {
    if (abs($vars[$i]) >= 0.01) {$v = sprintf("%.3f", $vars[$i]);}
    else {$v = sprintf("%.4f", $vars[$i]);}
    print OUT "\t$v";
  }
  print OUT "\n";
}
