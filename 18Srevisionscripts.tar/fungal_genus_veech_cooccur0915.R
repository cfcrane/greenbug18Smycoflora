## Veech (2013) probabilistic pairwise species co-occurrence test, applied
## to the WGCNA module genera -- testing the hypothesis that modules reflect
## mutually antagonistic (negatively co-occurring) groups of fungal genera.
##
## The CRAN 'cooccur' package (Griffith, Veech & Marsh 2016, J. Stat. Softw.,
## which implements Veech 2013, Global Ecol. Biogeogr.) is not available for
## this R version, so the underlying hypergeometric test is implemented
## directly here -- it is exactly what 'cooccur' computes internally.
##
## For each genus pair, given N total samples, N1 = samples where genus 1
## is detected, N2 = samples where genus 2 is detected, and obs = samples
## where BOTH are detected: under the null hypothesis that the two genera
## are independently, randomly distributed among samples (holding each
## genus's own occurrence frequency fixed), the number of co-occurrences
## follows a hypergeometric distribution. This gives an exact p-value for
## "co-occur significantly LESS than expected" (p_lt, consistent with
## mutual exclusion/antagonism) and "co-occur significantly MORE than
## expected" (p_gt, consistent with shared habitat preference/facilitation)
## -- WITHOUT needing simulation.
##
## Pairs are classified as within-module (both genera share a WGCNA module)
## or between-module, so the antagonism hypothesis -- that DIFFERENT
## modules are the ones showing negative co-occurrence -- can be tested
## directly: if real, between-module pairs should be enriched for
## significant negative associations relative to within-module pairs.
##
## Benjamini-Hochberg correction is applied globally across all p_lt and
## all p_gt values separately (this project's standing convention for
## multiple-testing correction), not per module or per biotype-subset.
##
## Same rarefaction depth (25750), grey-module exclusion, and
## Mortierella+Mortierellaceae merge-handling as the other module-level
## tests, for comparability.

suppressMessages(library(vegan))

rarefy_depth <- 25750
set.seed(42)
alpha <- 0.05

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
tot <- colSums(counts)

run_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- grep(paste0("^", bt), colnames(counts), value = TRUE)
  ids <- ids[tot[ids] >= rarefy_depth]

  mat <- t(counts[, ids])
  mat_rare <- rrarefy(mat, sample = rarefy_depth)

  mod <- read.delim(paste0("gb18Sfungwgcna_biotype", bt, "_modules.txt"), stringsAsFactors = FALSE)
  mod <- mod[mod$module != "grey", ]
  if ("Mortierella+Mortierellaceae" %in% mod$genus && !("Mortierella+Mortierellaceae" %in% colnames(mat_rare))) {
    merged_col <- rowSums(mat_rare[, c("Mortierella", "Mortierellaceae"), drop = FALSE])
    mat_rare <- mat_rare[, !(colnames(mat_rare) %in% c("Mortierella", "Mortierellaceae"))]
    mat_rare <- cbind(mat_rare, "Mortierella+Mortierellaceae" = merged_col)
  }

  common_genera <- intersect(mod$genus, colnames(mat_rare))
  module_map <- setNames(mod$module, mod$genus)[common_genera]

  incidence <- (t(mat_rare[, common_genera]) > 0) * 1   # genera x samples
  N <- ncol(incidence)
  n_genera <- nrow(incidence)
  cat(sprintf("Genera tested: %d, samples: %d, pairs: %d\n", n_genera, N, choose(n_genera, 2)))

  pairs <- combn(common_genera, 2)
  n_pairs <- ncol(pairs)

  g1 <- pairs[1, ]; g2 <- pairs[2, ]
  N1 <- rowSums(incidence)[g1]
  N2 <- rowSums(incidence)[g2]
  obs <- vapply(seq_len(n_pairs), function(i) sum(incidence[g1[i], ] & incidence[g2[i], ]), integer(1))
  expected <- N1 * N2 / N

  p_lt <- phyper(obs, N1, N - N1, N2)               # P(co-occur <= obs): evidence of segregation/antagonism
  p_gt <- 1 - phyper(pmax(obs - 1, -1), N1, N - N1, N2)  # P(co-occur >= obs): evidence of aggregation

  q_lt <- p.adjust(p_lt, method = "BH")
  q_gt <- p.adjust(p_gt, method = "BH")

  same_module <- module_map[g1] == module_map[g2]

  assoc <- ifelse(q_lt < alpha, "negative", ifelse(q_gt < alpha, "positive", "random"))

  df <- data.frame(genus1 = g1, genus2 = g2, module1 = module_map[g1], module2 = module_map[g2],
                    same_module = same_module, N1 = N1, N2 = N2, observed = obs,
                    expected = round(expected, 2), p_lt = p_lt, p_gt = p_gt,
                    q_lt = q_lt, q_gt = q_gt, association = assoc,
                    stringsAsFactors = FALSE)

  cat("\n--- Overall association counts (BH q < 0.05) ---\n")
  print(table(df$association))

  cat("\n--- Association counts by within- vs between-module pair ---\n")
  print(table(df$same_module, df$association))

  cat("\n--- Proportion of pairs significantly NEGATIVE (segregated), by pair type ---\n")
  neg_rate <- tapply(df$association == "negative", df$same_module, mean)
  print(neg_rate)
  if (sum(df$association == "negative") == 0) {
    cat("\nNo pairs were significantly negatively associated (BH q < 0.05) -- Fisher's test skipped.\n")
  } else {
    cat(sprintf("\nFisher's exact test: is negative association enriched among %s pairs?\n",
                if (isTRUE(neg_rate["FALSE"] > neg_rate["TRUE"])) "between-module" else "within-module"))
    ft <- fisher.test(table(df$same_module, df$association == "negative"))
    print(ft)
  }

  cat("\n--- Proportion of pairs significantly POSITIVE (aggregated), by pair type ---\n")
  pos_rate <- tapply(df$association == "positive", df$same_module, mean)
  print(pos_rate)
  if (sum(df$association == "positive") > 0 && length(unique(df$same_module)) == 2) {
    ft2 <- fisher.test(table(df$same_module, df$association == "positive"))
    cat("\nFisher's exact test: is positive association enriched within-module?\n")
    print(ft2)
  }

  fname <- paste0("fungal_veech_cooccur_biotype", bt, ".tsv")
  write.table(df, fname, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("\nWritten:", fname, "\n")

  invisible(df)
}

resE <- run_for_biotype("E")
resK <- run_for_biotype("K")
