#!/usr/bin/env perl
use warnings;
#This script looked for quote-bounded strings in R script lines containing "library" or "require".
open (LIS, "< $ARGV[0]"); #Rfiles0904.txt
open (OUT, "> $ARGV[1]");
while ($file = <LIS>) {
  chomp $file;
  open (INP, "< $file");
  while ($line = <INP>) {
    if ($line =~ m/vegan/) {print OUT $file, " contains vegan.\n";}
    if ($line =~ m/library/ || $line =~ m/require/) {
      print OUT $line;
      chomp $line;
      $line =~ s/\t//g; $line =~ s/ //g;
      @vars = split(/\(|\)/, $line);
      #suppressPackageStartupMessages(library(ggplot2))
      for ($i = 0; $i < scalar(@vars); $i++) {
        if ($vars[$i] eq "library" || $vars[$i] eq "require") {
          print OUT "\t$vars[$i+1]\n";
          if (exists($counts{$vars[$i+1]})) {$counts{$vars[$i+1]}++;}
          else {$counts{$vars[$i+1]} = 1;}
        }
      }
    }
  }
}
for $key (sort(keys(%counts))) {print OUT "$key\t$counts{$key}\n";}
