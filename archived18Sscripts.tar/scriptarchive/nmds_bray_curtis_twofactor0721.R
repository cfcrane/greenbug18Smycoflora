## Counterpart to nmds_bray_curtis0716a.R: instead of ordination, this checks
## whether host_species x timepoint and host_cultivar x timepoint are balanced
## factorial designs, then runs two-factor PERMANOVA (adonis2) for each pair
## so the timepoint interaction (does the host effect change over time?) is
## visible as its own term, rather than being folded into Residual the way it
## is in the single-factor models.
##
## adonis2's default sequential (Type I) sum-of-squares is order-dependent:
## the FIRST main effect's SS gets credit for any variance it shares with the
## second main effect. The interaction term itself is unaffected by order --
## it is always fit last, after both main effects, regardless of which comes
## first. So order only matters for interpreting the two main-effect SS/R2/F
## values, not the interaction's.
##
## Practical consequence used below: if a factor pair's design turns out to
## be balanced (every combination present, all filled cells equal size), term
## order doesn't matter and only "other_var x timepoint" is run. If it's
## unbalanced, the reversed order ("timepoint x other_var") is also run, so
## both sequential partitions are on record instead of just one arbitrary one.
##
## *_distance_matrix.qza is a zip archive; the actual matrix lives at
## <uuid>/data/distance-matrix.tsv inside it, extracted here directly (no
## qiime2R dependency needed for this one file type) -- same as
## nmds_bray_curtis0716a.R.

## ---- CONFIG ----
distance_matrix_qza <- "E_bray_curtis_distance_matrix.qza"
metadata_file        <- "metadataforbiotypeE0715.txt"
sample_id_col        <- "ID"             # column in metadata_file holding sample IDs
species_var          <- "host_species"
cultivar_var         <- "host_cultivar"
timepoint_var        <- "timepoint"
n_permutations       <- 4999             # for adonis2
out_prefix           <- "E_bray_curtis_twofactor"
seed                 <- 11279929         # for reproducible permutation p-values
timepoint_levels_to_drop <- c("t0")      # e.g. c("t0"); use character(0) to keep all timepoints
## -----------------

if (length(timepoint_levels_to_drop) > 0) {
  out_prefix <- paste0(out_prefix, "_excl_", paste(timepoint_levels_to_drop, collapse = ""))
}

pkgs <- c("vegan")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
suppressMessages(library(vegan))

## Extract data/distance-matrix.tsv from the .qza (a zip archive) and load it
read_qza_distance <- function(path) {
  entries <- unzip(path, list = TRUE)$Name
  dm_entry <- entries[grepl("data/distance-matrix\\.tsv$", entries)]
  if (length(dm_entry) != 1) {
    stop("Expected exactly one data/distance-matrix.tsv inside ", path,
         ", found ", length(dm_entry))
  }
  tmp_dir <- tempfile("qza_")
  dir.create(tmp_dir)
  unzip(path, files = dm_entry, exdir = tmp_dir)
  dm <- read.delim(file.path(tmp_dir, dm_entry), row.names = 1, check.names = FALSE)
  unlink(tmp_dir, recursive = TRUE)
  as.dist(as.matrix(dm))
}

cat("Reading distance matrix:", distance_matrix_qza, "\n")
dm <- read_qza_distance(distance_matrix_qza)
dist_labels <- attr(dm, "Labels")
cat(sprintf("Loaded a %d-sample Bray-Curtis distance matrix.\n", length(dist_labels)))

meta <- read.delim(metadata_file, check.names = FALSE, stringsAsFactors = FALSE)
meta <- meta[meta[[sample_id_col]] != "#q2:types", ]  # drop QIIME2 metadata type-declaration row, if present
names(meta)[names(meta) == sample_id_col] <- "sample_id"

## Align metadata to the distance matrix's own sample order (required by adonis2)
meta_sub <- meta[match(dist_labels, meta$sample_id), ]
unmatched <- dist_labels[is.na(meta_sub$sample_id)]
if (length(unmatched) > 0) {
  stop("Distance-matrix sample(s) not found in metadata: ", paste(unmatched, collapse = ", "))
}
## Optionally drop timepoint level(s) (e.g. t0, which most species/cultivars
## were never sampled at) before checking balance / running PERMANOVA -- a
## level sampled for only one or two groups creates empty design cells that
## swamp any milder, single-replicate-dropout imbalance elsewhere.
if (length(timepoint_levels_to_drop) > 0) {
  keep <- !(meta_sub[[timepoint_var]] %in% timepoint_levels_to_drop)
  cat(sprintf("\nDropping timepoint level(s) %s: removing %d of %d samples.\n",
              paste(timepoint_levels_to_drop, collapse = ", "), sum(!keep), length(keep)))
  meta_sub <- meta_sub[keep, ]
  dm <- as.dist(as.matrix(dm)[meta_sub$sample_id, meta_sub$sample_id])
}

meta_sub[[species_var]]   <- factor(meta_sub[[species_var]])
meta_sub[[cultivar_var]]  <- factor(meta_sub[[cultivar_var]])
meta_sub[[timepoint_var]] <- factor(meta_sub[[timepoint_var]])

cat(sprintf("Matched %d samples: %d %s levels, %d %s levels, %d %s levels\n",
            nrow(meta_sub),
            nlevels(meta_sub[[species_var]]), species_var,
            nlevels(meta_sub[[cultivar_var]]), cultivar_var,
            nlevels(meta_sub[[timepoint_var]]), timepoint_var))

run_permanova <- function(formula, label, suffix) {
  cat(sprintf("\n---- PERMANOVA: %s ----\n", label))
  set.seed(seed)
  res <- adonis2(formula, data = meta_sub, permutations = n_permutations, by = "terms")
  print(res)
  fname <- paste0(out_prefix, "_permanova_", suffix, ".txt")
  write.table(as.data.frame(res), fname, sep = "\t", quote = FALSE, col.names = NA)
  cat("Written:", fname, "\n")
  invisible(res)
}

## Checks a two-way cross-tab for balance, then runs the two-factor PERMANOVA
## with `other_var` first (e.g. "species x timepoint"). If the design is
## unbalanced, also runs it with `timepoint_var` first ("timepoint x species"),
## since sequential SS assigns shared variance to whichever main effect comes
## first in the formula.
run_pair <- function(other_var, other_name, tp_var) {
  cat(sprintf("\n==== %s x %s ====\n", other_name, tp_var))
  tab <- table(meta_sub[[other_var]], meta_sub[[tp_var]])
  cat(sprintf("Cross-tabulation (rows = %s, cols = %s):\n", other_name, tp_var))
  print(tab)

  zero_cells <- sum(tab == 0)
  filled <- tab[tab > 0]
  balanced <- (zero_cells == 0) && (length(unique(filled)) == 1)

  if (zero_cells > 0) {
    cat(sprintf("-> UNBALANCED: %d of %d factor combinations have zero samples.\n",
                zero_cells, length(tab)))
  } else if (!balanced) {
    cat(sprintf("-> UNBALANCED: filled-cell sizes range from %d to %d (not all equal).\n",
                min(filled), max(filled)))
  } else {
    cat(sprintf("-> BALANCED: all %d filled cells have n = %d.\n", length(filled), filled[1]))
  }

  f1 <- as.formula(paste("dm ~", other_var, "*", tp_var))
  run_permanova(f1, sprintf("%s x %s", other_name, tp_var),
                sprintf("%s_x_%s", other_name, tp_var))

  if (!balanced) {
    f2 <- as.formula(paste("dm ~", tp_var, "*", other_var))
    run_permanova(f2, sprintf("%s x %s (reversed term order)", tp_var, other_name),
                  sprintf("%s_x_%s", tp_var, other_name))
    cat("(Design is unbalanced, so the reversed term order was also run --\n",
        "the two main-effect rows above and here can differ; the interaction\n",
        "row is identical in both since it is always fit last.)\n", sep = "")
  }
}

run_pair(species_var, "species", timepoint_var)
run_pair(cultivar_var, "cultivar", timepoint_var)

cat("\nDone.\n")
