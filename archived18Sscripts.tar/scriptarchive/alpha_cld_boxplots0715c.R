## Boxplots of observed_features and shannon_entropy alpha diversity, with
## compact letter display (CLD) annotating which groups differ significantly.
##
## Intended for the *_vector.qza outputs of `qiime diversity core-metrics-phylogenetic`
## (observed_features_vector.qza, shannon_vector.qza), after exporting each with:
##   qiime tools export --input-path observed_features_vector.qza --output-path observed_features_exported
##   qiime tools export --input-path shannon_vector.qza            --output-path shannon_exported
## Each export produces an alpha-diversity.tsv with columns: sample-id, <metric>.
##
## Statistics follow this project's established convention (see e.g.
## gb18Skruskalbiotypeforshannon.csv / gb18SkruskalbiotypeBHqvals.txt):
## Kruskal-Wallis omnibus test, then Dunn's post-hoc pairwise test with
## Benjamini-Hochberg correction applied across all C(n,2) pairs, then
## multcompView::multcompLetters() converts the BH-adjusted pairwise p-values
## into a compact letter display at alpha = 0.05 (groups sharing a letter are
## not significantly different).

## ---- CONFIG -- edit these paths/values for your data ----
observed_features_file <- "E_obsfeatdiversity.tsv"
shannon_file            <- "E_shannondiversity.tsv"
metadata_file           <- "metadataforbiotypeE0715.txt"
sample_id_col           <- "ID"              # column in metadata_file holding sample IDs
group_var               <- "host_cultivar"    # metadata column to compare groups on
alpha                   <- 0.05
out_prefix              <- "gb18SalphadiversityboxplotsforE_hostcultivar"
## -----------------------------------------------------------

pkgs <- c("dplyr", "ggplot2", "FSA", "multcompView", "svglite")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")

suppressMessages({
  library(dplyr)
  library(ggplot2)
  library(FSA)
  library(multcompView)
})

read_alpha <- function(path, value_col) {
  d <- read.delim(path, check.names = FALSE, stringsAsFactors = FALSE)
  names(d)[1] <- "sample_id"
  names(d)[2] <- value_col
  d[, c("sample_id", value_col)]
}

obs <- read_alpha(observed_features_file, "observed_features")
sha <- read_alpha(shannon_file, "shannon_entropy")

meta <- read.delim(metadata_file, check.names = FALSE, stringsAsFactors = FALSE)
meta <- meta[meta[[sample_id_col]] != "#q2:types", ]  # drop QIIME2 metadata type-declaration row, if present
names(meta)[names(meta) == sample_id_col] <- "sample_id"

df <- obs |>
  inner_join(sha, by = "sample_id") |>
  inner_join(meta[, c("sample_id", group_var)], by = "sample_id")

df[[group_var]] <- factor(df[[group_var]])
df$observed_features <- as.numeric(df$observed_features)
df$shannon_entropy   <- as.numeric(df$shannon_entropy)

cat(sprintf("Merged %d samples across %d levels of '%s'\n",
            nrow(df), nlevels(df[[group_var]]), group_var))

## Kruskal-Wallis -> Dunn's post-hoc (BH-adjusted) -> compact letter display
get_cld <- function(value_col) {
  form <- as.formula(paste(value_col, "~", group_var))

  kw <- kruskal.test(form, data = df)
  cat(sprintf("\n%s: Kruskal-Wallis chi-sq=%.3f, df=%d, p=%.4g\n",
              value_col, kw$statistic, kw$parameter, kw$p.value))

  dunn <- dunnTest(form, data = df, method = "bh")$res
  pvals <- setNames(dunn$P.adj, gsub(" ", "", dunn$Comparison))  # "GroupA-GroupB" naming multcompLetters expects

  letters_out <- multcompLetters(pvals, threshold = alpha)$Letters
  list(
    kw = kw,
    dunn = dunn,
    cld = data.frame(group = names(letters_out), letter = unname(letters_out),
                      stringsAsFactors = FALSE)
  )
}

res_obs <- get_cld("observed_features")
res_sha <- get_cld("shannon_entropy")

write.table(res_obs$dunn, paste0(out_prefix, "_observed_features_dunn.txt"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(res_sha$dunn, paste0(out_prefix, "_shannon_dunn.txt"),
            sep = "\t", quote = FALSE, row.names = FALSE)
cat("\nWritten Dunn's test tables:", paste0(out_prefix, "_observed_features_dunn.txt"),
    "/", paste0(out_prefix, "_shannon_dunn.txt"), "\n")

## Boxplot with CLD letters placed above each box
plot_metric <- function(value_col, res, ylab) {
  cld <- res$cld
  names(cld)[1] <- group_var

  label_y <- df |>
    group_by(.data[[group_var]]) |>
    summarise(y = max(.data[[value_col]], na.rm = TRUE), .groups = "drop") |>
    left_join(cld, by = group_var) |>
    mutate(y = y + 0.06 * diff(range(df[[value_col]], na.rm = TRUE)))

  ggplot(df, aes(x = .data[[group_var]], y = .data[[value_col]])) +
    geom_boxplot(outlier.shape = NA, fill = "grey90") +
    geom_jitter(width = 0.12, size = 0.8, alpha = 0.5) +
    geom_text(data = label_y, aes(x = .data[[group_var]], y = y, label = letter),
              inherit.aes = FALSE, size = 2.5) +
    labs(x = group_var, y = ylab) +
    theme_bw(base_size = 10) +
    theme(axis.text.x = element_text(angle = 40, hjust = 1))
}

p_obs <- plot_metric("observed_features", res_obs, "Observed Features")
p_sha <- plot_metric("shannon_entropy", res_sha, "Shannon Diversity Index")

for (fmt in c("pdf", "svg")) {
  ggsave(paste0(out_prefix, "_observed_features.", fmt), p_obs, width = 4, height = 3.25)
  ggsave(paste0(out_prefix, "_shannon.", fmt), p_sha, width = 4, height = 3.25)
}

cat("\nWritten figures:\n",
    out_prefix, "_observed_features.{pdf,svg}\n",
    out_prefix, "_shannon.{pdf,svg}\n", sep = "")
