## For each biotype x guild roster in guildrosters0715.txt, sum genus counts
## (restricted to that biotype's samples in fung_genus_forbiom.txt), find the
## most abundant roster genus, and its percentage of the guild's total count.
##
## Name matching: roster member names use inconsistent separators/spelling
## relative to the count table (e.g. "Capnodiales_gen_Incertae_sedis" vs.
## "Capnodiales genus incertae sedis"), so both sides are normalized to a
## bare-alphanumeric key ("genus" folded to "gen") before matching.
## "Mortierella+Mortierellaceae" is a single roster entry representing the
## sum of the two separate genus rows in the count table.

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)
samp_ids <- colnames(counts)
biotype_of_sample <- substr(samp_ids, 1, 1)  # "E" or "K"

norm_key <- function(x) {
  x <- gsub("[‘’“”]", "", x)   # strip curly quotes
  x <- tolower(x)
  x <- gsub("genus", "gen", x)
  x <- gsub("[^a-z0-9]", "", x)
  x
}

genus_keys <- norm_key(rownames(counts))
names(genus_keys) <- rownames(counts)
key_to_genus <- setNames(rownames(counts), genus_keys)

lookup_count <- function(member_name, biotype) {
  cols <- samp_ids[biotype_of_sample == biotype]
  parts <- trimws(strsplit(member_name, "\\+")[[1]])
  total <- 0
  matched_names <- character(0)
  for (p in parts) {
    k <- norm_key(p)
    g <- key_to_genus[[k]]
    if (is.null(g) || is.na(g)) {
      stop(paste0("No match found in count table for roster member: '", p,
                   "' (normalized key: '", k, "')"))
    }
    matched_names <- c(matched_names, g)
    total <- total + sum(as.numeric(counts[g, cols]))
  }
  total
}

lines <- readLines("guildrosters0715.txt")

out <- lines[1:4]  # header/pattern-description lines, unchanged

i <- 5
while (i <= length(lines)) {
  biotype <- trimws(lines[i])
  guild   <- trimws(lines[i + 1])
  n_val   <- trimws(lines[i + 2])
  members_line <- if (i + 3 <= length(lines)) lines[i + 3] else ""

  out <- c(out, lines[i], lines[i + 1], lines[i + 2], members_line)

  if (nchar(trimws(members_line)) == 0) {
    out <- c(out, "(no roster -- unaffiliated genera excluded from this summary)")
  } else {
    members <- trimws(strsplit(members_line, ",")[[1]])

    member_counts <- sapply(members, lookup_count, biotype = biotype)
    total_guild <- sum(member_counts)
    top_idx <- which.max(member_counts)
    top_member <- members[top_idx]
    top_count <- member_counts[top_idx]
    pct <- 100 * top_count / total_guild

    out <- c(out, sprintf("Most abundant genus: %s (%.2f%% of guild total counts)",
                           top_member, pct))

    cat(sprintf("Biotype %s / guild %s: total=%d, top=%s (%.2f%%)\n",
                biotype, guild, total_guild, top_member, pct))
  }

  i <- i + 4
}

writeLines(out, "guildrosters0715_withsummary.txt")
cat("\nWritten: guildrosters0715_withsummary.txt\n")
