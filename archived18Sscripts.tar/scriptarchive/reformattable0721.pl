#!/usr/bin/env perl
use warnings;
use Scalar::Util qw(looks_like_number);
#This script rounds decimal values in a table but leaves integers alone.
open (INP, "< $ARGV[0]"); #
open (OUT, "> $ARGV[1]");
$line = <INP>;
print OUT $line;
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  for ($i = 0; $i < scalar(@vars); $i++) {
    if (looks_like_number($vars[$i])) {
      if ($vars[$i] =~ m/\./) {
        $v = sprintf("%9.3f", $vars[$i]);
        $v =~ s/ //g;
        if ($i > 0) {print OUT "\t$v";}
        else {print OUT $v;}
      }
      else {
        if ($i > 0) {print OUT "\t$vars[$i]";}
        else {print OUT $vars[$i];}
      }
    }
    else {
      if ($i > 0) {print OUT "\t$vars[$i]";}
      else {print OUT $vars[$i];}
    }
  }
  print OUT "\n";
}
