## Four-factor PERMANOVA extending permanova_threefactor_biotype_species_timepoint0721.R
## by adding susceptibility as a fourth factor: dm ~ biotype * host_species *
## timepoint * susceptibility (t0 excluded). Same rarefaction (to a common,
## user-specified depth) and Bray-Curtis construction as that script.
##
## IMPORTANT CAVEAT, checked before running the real permutation test:
## susceptibility is heavily confounded with host_species, not just
## imbalanced --
##   Aegilops_triuncialis: 100% "not_tested" (0 resistant, 0 susceptible)
##   sorghum:              "not_tested"/"susceptible" only (0 resistant)
##   barley, rye, wheat:   both "resistant" and "susceptible" represented
## This leaves several host_species x susceptibility cells structurally
## empty (not just small), which makes the full 4-way model matrix rank
## deficient (confirmed: 90 model.matrix columns, rank 60 -- 30 aliased). R
## handles this the same way lm() handles collinear predictors: it silently
## drops the aliased columns via QR pivoting rather than erroring, so
## adonis2 still runs, but any term involving BOTH host_species and
## susceptibility (their 2-way interaction, and the two 3-way/1 four-way
## terms that contain it) is reporting a reduced-df, order-dependent
## partition, not a full, cleanly interpretable interaction contrast -- there
## simply isn't a resistant/susceptible contrast to test for
## Aegilops_triuncialis or (the resistant side of) sorghum. Terms not
## involving that specific pairing (biotype, timepoint, susceptibility
## itself, biotype:host_species, biotype:timepoint, host_species:timepoint,
## etc.) are unaffected by the aliasing and can be read normally.
##
## Two sequential (by = "terms") orderings are still run for the same reason
## as the three-factor script: to check whether the ranking of effects is
## robust to formula order given the (now two separate sources of)
## imbalance. The four-way interaction row is identical in both regardless
## of order, since it is always fit last.

## ---- CONFIG ----
counts_file          <- "fung_genus_forbiom.txt"
metadata_files       <- c("metadataforbiotypeE0715.txt", "metadataforbiotypeK0715.txt")
sample_id_col        <- "ID"
biotype_var          <- "biotype"
species_var          <- "host_species"
timepoint_var        <- "timepoint"
susceptibility_var   <- "susceptibility"
timepoint_levels_to_drop <- c("t0")   # e.g. c("t0"); use character(0) to keep all timepoints
rarefaction_depth    <- 25670         # user-specified common sequencing depth
n_permutations       <- 4999
out_prefix           <- "fourfactor_biotype_species_timepoint_susceptibility0721"
seed                 <- 11279929      # for reproducible rarefaction draw AND permutation p-values
## -----------------

if (length(timepoint_levels_to_drop) > 0) {
  out_prefix <- paste0(out_prefix, "_excl_", paste(timepoint_levels_to_drop, collapse = ""))
}
out_prefix <- paste0(out_prefix, "_rar", rarefaction_depth)

pkgs <- c("vegan")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
suppressMessages(library(vegan))

## ---- Load genus x sample counts (both biotypes combined) ----
cat("Reading counts:", counts_file, "\n")
counts <- read.delim(counts_file, check.names = FALSE, row.names = 1)
cat(sprintf("Loaded %d genera x %d samples.\n", nrow(counts), ncol(counts)))

## ---- Load and combine metadata from both biotypes ----
meta_list <- lapply(metadata_files, function(f) {
  m <- read.delim(f, check.names = FALSE, stringsAsFactors = FALSE)
  m[m[[sample_id_col]] != "#q2:types", ]  # drop QIIME2 metadata type-declaration row, if present
})
meta <- do.call(rbind, meta_list)
names(meta)[names(meta) == sample_id_col] <- "sample_id"
cat(sprintf("Combined metadata: %d samples across %d file(s).\n", nrow(meta), length(metadata_files)))

dup_ids <- meta$sample_id[duplicated(meta$sample_id)]
if (length(dup_ids) > 0) {
  stop("Duplicate sample_id(s) across metadata files: ", paste(unique(dup_ids), collapse = ", "))
}

unmatched_counts <- setdiff(colnames(counts), meta$sample_id)
unmatched_meta   <- setdiff(meta$sample_id, colnames(counts))
if (length(unmatched_counts) > 0) {
  stop("Sample(s) in ", counts_file, " not found in metadata: ", paste(unmatched_counts, collapse = ", "))
}
if (length(unmatched_meta) > 0) {
  stop("Sample(s) in metadata not found in ", counts_file, ": ", paste(unmatched_meta, collapse = ", "))
}

## ---- Drop timepoint level(s), e.g. t0 ----
if (length(timepoint_levels_to_drop) > 0) {
  keep <- !(meta[[timepoint_var]] %in% timepoint_levels_to_drop)
  cat(sprintf("\nDropping timepoint level(s) %s: removing %d of %d samples.\n",
              paste(timepoint_levels_to_drop, collapse = ", "), sum(!keep), length(keep)))
  meta <- meta[keep, ]
}
counts <- counts[, meta$sample_id, drop = FALSE]  # align column order to meta's row order

## ---- Rarefy every remaining sample to a common depth ----
depths <- colSums(counts)
too_shallow <- names(depths)[depths < rarefaction_depth]
if (length(too_shallow) > 0) {
  cat(sprintf("\nDropping %d sample(s) below rarefaction depth %d: %s\n",
              length(too_shallow), rarefaction_depth, paste(too_shallow, collapse = ", ")))
  counts <- counts[, setdiff(colnames(counts), too_shallow), drop = FALSE]
  meta   <- meta[meta$sample_id %in% colnames(counts), ]
}
counts <- counts[, meta$sample_id, drop = FALSE]  # re-align after any drops

cat(sprintf("Rarefying %d samples to %d counts each (seed = %d)...\n",
            ncol(counts), rarefaction_depth, seed))
set.seed(seed)
rarefied <- rrarefy(t(counts), sample = rarefaction_depth)  # rrarefy expects samples as rows

## ---- Bray-Curtis distance on the rarefied community table ----
dm <- vegdist(rarefied, method = "bray")
cat(sprintf("Built a %d-sample Bray-Curtis distance matrix from rarefied counts.\n", nrow(rarefied)))

stopifnot(identical(labels(dm), meta$sample_id))

meta[[biotype_var]]        <- factor(meta[[biotype_var]])
meta[[species_var]]        <- factor(meta[[species_var]])
meta[[timepoint_var]]      <- factor(meta[[timepoint_var]])
meta[[susceptibility_var]] <- factor(meta[[susceptibility_var]])

cat(sprintf("\nFactor levels: %d %s, %d %s, %d %s, %d %s\n",
            nlevels(meta[[biotype_var]]), biotype_var,
            nlevels(meta[[species_var]]), species_var,
            nlevels(meta[[timepoint_var]]), timepoint_var,
            nlevels(meta[[susceptibility_var]]), susceptibility_var))

## ---- Balance / confounding diagnostics ----
cat("\n==== host_species x susceptibility cross-tabulation ====\n")
tab_sxs <- table(meta[[species_var]], meta[[susceptibility_var]])
print(tab_sxs)
zero_sxs <- sum(tab_sxs == 0)
cat(sprintf("-> %d of %d host_species x susceptibility cells are empty (structural confounding,\n",
            zero_sxs, length(tab_sxs)))
cat("   not just imbalance) -- terms involving both host_species and susceptibility\n",
    "   are reduced-df/aliased; see the header comment for which terms that affects.\n", sep = "")

cat("\n==== biotype x host_species x timepoint x susceptibility cross-tabulation ====\n")
tab4 <- table(meta[[biotype_var]], meta[[species_var]], meta[[timepoint_var]], meta[[susceptibility_var]])
zero_cells <- sum(tab4 == 0)
filled <- tab4[tab4 > 0]
cat(sprintf("%d of %d factor-combination cells are empty; filled-cell sizes range from %d to %d.\n",
            zero_cells, length(tab4), min(filled), max(filled)))
unbalanced <- (zero_cells > 0 || length(unique(filled)) > 1)
if (unbalanced) {
  cat("-> UNBALANCED design: sequential (by=\"terms\") main-effect/interaction SS below\n",
      "   are order-dependent; the reversed-order run afterwards checks robustness.\n", sep = "")
} else {
  cat("-> BALANCED design: term order should not matter.\n")
}

## ---- Full factorial four-factor PERMANOVA (sequential SS) ----
run_permanova <- function(vars, suffix, label) {
  form <- as.formula(paste("dm ~", paste(vars, collapse = " * ")))
  cat(sprintf("\n---- PERMANOVA (%s) ----\n", label))
  set.seed(seed)
  res <- adonis2(form, data = meta, permutations = n_permutations, by = "terms")
  print(res)
  fname <- paste0(out_prefix, "_permanova_", suffix, ".txt")
  write.table(as.data.frame(res), fname, sep = "\t", quote = FALSE, col.names = NA)
  cat("Written:", fname, "\n")
  invisible(res)
}

run_permanova(c(biotype_var, species_var, timepoint_var, susceptibility_var),
              "seq_biotype_species_timepoint_susceptibility",
              "sequential, order = biotype, host_species, timepoint, susceptibility (as requested)")

if (unbalanced) {
  run_permanova(c(susceptibility_var, timepoint_var, species_var, biotype_var),
                "seq_susceptibility_timepoint_species_biotype",
                "sequential, REVERSED order = susceptibility, timepoint, host_species, biotype")
  cat("(Design is unbalanced/confounded, so the reversed order was also run -- compare\n",
      "each main effect's R2/F across the two tables; the four-way interaction row is\n",
      "identical in both since it is always fit last.)\n", sep = "")
}

cat("\nDone.\n")
