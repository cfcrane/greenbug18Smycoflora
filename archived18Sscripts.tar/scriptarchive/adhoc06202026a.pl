#!/usr/bin/env perl
use warnings;
#This script built the coldata metadata file for DESeq2 on wheat RNA samples.
open (INA, "< $ARGV[0]"); #wheatgenecountfiles0620.txt
open (INB, "< $ARGV[1]"); #SRR32566accessionstocodes.csv
open (OUT, "> $ARGV[2]");
$searchstringa = $ARGV[3]; #SRR325
$searchstringb = $ARGV[4]; #RPV
print OUT "sampleName\tfile\tbiotype\tvirus\tday\treplicate\n";
while ($line = <INA>) {
  chomp $line;
  #wheatgenecounts/genecountsfor_SRR32566734_genecounts.txt
  @vars = split(/_/, $line);
  for ($i = 0; $i < scalar(@vars); $i++) {
    if ($vars[$i] =~ m/$searchstringa/) {$accession = $vars[$i]; $files{$accession} = $line;}
  }
}
$line = <INB>; #Skip the header.
while ($line = <INB>) {
  chomp $line;
  @vars = split(/,/, $line);
  #SRR32566714,RNA-Seq,300,8243951666,replicate 2,PRJNA1231475,SAMN47212671,Plant,2767235393,USDA-ARS-MWA,2019-12-22,public,Newton,"sra,fastq,run.zq","gs,ncbi,s3","ncbi.public,gs.us-east1,s3.us-east-1",vegetative,SRX27876407,USA,North America,"USA: West Lafayette, Indiana",Illumina NovaSeq 6000,40.4228 N 86.9154 W,WHRPV72,PAIRED,PolyA,TRANSCRIPTOMIC,Triticum aestivum,ILLUMINA,2025-03-04T00:00:00Z,2025-03-04T13:59:00Z,1,WHRPV72,SRP567839,leaf blade,WHRPV72
  $accession = $vars[0];
  $code = $vars[-1];
  if ($code =~ m/$searchstringb/) {$virus = "carrier";}
  else {$virus = "virus_free";}
  if ($code =~ m/H/) {$biotype = "H";}
  elsif ($code =~ m/B/) {$biotype = "B";}
  else {$biotype = "not_infested";}
  $daterep = substr($code, -2);
  $dateindex = substr($daterep, 0, 1);
  $replicate = substr($daterep, -1);
  if ($dateindex == 0) {$day = 0;}
  elsif ($dateindex == 1) {$day = 1;}
  elsif ($dateindex == 2) {$day = 2;}
  elsif ($dateindex == 3) {$day = 3;}
  elsif ($dateindex == 4) {$day = 5;}
  elsif ($dateindex == 5) {$day = 10;}
  elsif ($dateindex == 6) {$day = 15;}
  elsif ($dateindex == 7) {$day = 20;}
  #print OUT "sampleName\tfile\tbiotype\tvirus\tday\treplicate\n";
  print OUT "$code\t$files{$accession}\t$biotype\t$virus\t$day\t$replicate\n";
}
