#!/usr/bin/perl
# relabelbacttable.pl
#
# Rename the sample columns of the bacterial feature table
# (convertedfeaturetable.txt) from the "16sP<plate>_<well>_<code>" format
# to the dashed "<code>-<timepoint><replicate>" format used by the fungal
# table, using a two-column crosswalk.  Columns with no crosswalk entry
# (e.g. blanks / unused wells) are dropped, so the output table's sample
# columns line up one-to-one with the fungal table's sample IDs.
#
# Usage:
#   perl relabelbacttable.pl <crosswalk.tsv> <convertedfeaturetable.txt> > bact_relabeled.txt
#
# crosswalk.tsv : two tab-separated columns, no header required:
#     col1 = bacterial column name exactly as in convertedfeaturetable.txt
#            (e.g.  16sP2_F7_ER1)
#     col2 = fungal dashed sample id
#            (e.g.  ER1-12)
#   Lines beginning with '#' and blank lines are ignored.
#
# Notes:
#   * The bacterial table's first line ("# Constructed from biom file") is
#     dropped; the "#OTU ID" header line is rewritten with the new sample ids.
#   * The taxon-label column (#OTU ID) is always kept as column 1.
#   * A warning is printed to STDERR for every bacterial column that has no
#     crosswalk entry and for every crosswalk entry whose bacterial column
#     is absent from the table.

use strict;
use warnings;

die "Usage: perl relabelbacttable.pl <crosswalk.tsv> <bacterial_table.txt> > out.txt\n"
    unless @ARGV == 2;

my ($xwalkfile, $tablefile) = @ARGV;

# ---- load crosswalk -------------------------------------------------------
my %bact2fung;          # bacterial colname -> dashed id
open(my $X, '<', $xwalkfile) or die "Cannot open crosswalk '$xwalkfile': $!\n";
while (my $line = <$X>) {
    chomp $line;
    $line =~ s/\r$//;
    next if $line =~ /^\s*#/ || $line =~ /^\s*$/;
    my ($bact, $fung) = split /\t/, $line;
    unless (defined $bact && defined $fung && $bact ne '' && $fung ne '') {
        warn "Skipping malformed crosswalk line: $line\n";
        next;
    }
    $bact =~ s/^\s+|\s+$//g;
    $fung =~ s/^\s+|\s+$//g;
    if (exists $bact2fung{$bact} && $bact2fung{$bact} ne $fung) {
        warn "Crosswalk maps '$bact' to both '$bact2fung{$bact}' and '$fung'; keeping first.\n";
        next;
    }
    $bact2fung{$bact} = $fung;
}
close $X;

# ---- read table header to find sample columns -----------------------------
open(my $T, '<', $tablefile) or die "Cannot open table '$tablefile': $!\n";

# skip the leading "# Constructed from biom file" comment line(s) that precede
# the real header, but stop at the "#OTU ID" header.
my $header;
while (my $line = <$T>) {
    chomp $line;
    $line =~ s/\r$//;
    if ($line =~ /^#OTU ID\t/i || $line =~ /^#OTU ID$/i) { $header = $line; last; }
    next if $line =~ /^#/;     # other leading comments
    # If we reach a non-comment line first, treat it as the header.
    $header = $line; last;
}
die "Could not find a header row in '$tablefile'\n" unless defined $header;

my @cols = split /\t/, $header;
my $idname = shift @cols;                 # "#OTU ID"

# Decide which columns to keep and what to rename them to.
my @keep_idx;                             # 0-based indices into @cols to keep
my @newnames;                             # parallel new sample names
my %seen_target;
for (my $i = 0; $i < @cols; $i++) {
    my $c = $cols[$i];
    if (exists $bact2fung{$c}) {
        my $t = $bact2fung{$c};
        if ($seen_target{$t}++) {
            warn "Duplicate target id '$t' (from '$c'); dropping the duplicate.\n";
            next;
        }
        push @keep_idx, $i;
        push @newnames, $t;
    } else {
        warn "No crosswalk entry for bacterial column '$c'; dropping it.\n";
    }
}

# Warn about crosswalk entries that never matched a column.
my %present = map { $_ => 1 } @cols;
for my $b (sort keys %bact2fung) {
    warn "Crosswalk bacterial id '$b' not found in table header; ignored.\n"
        unless $present{$b};
}

die "No bacterial columns matched the crosswalk; nothing to write.\n"
    unless @keep_idx;

# ---- emit relabeled table -------------------------------------------------
print join("\t", $idname, @newnames), "\n";

while (my $line = <$T>) {
    chomp $line;
    $line =~ s/\r$//;
    next if $line =~ /^\s*$/;
    my @f = split /\t/, $line, -1;
    my $taxon = shift @f;
    my @vals = map { defined $f[$_] ? $f[$_] : '' } @keep_idx;
    print join("\t", $taxon, @vals), "\n";
}
close $T;

warn sprintf("Wrote %d sample columns (of %d in input).\n",
             scalar(@keep_idx), scalar(@cols));
