## Biotype x timepoint interaction test for Mortierella+Mortierellaceae,
## using the Scheirer-Ray-Hare test (rank-based nonparametric two-way ANOVA),
## implemented manually in base R since neither `rcompanion` nor `car` is
## installed. Procedure:
##   1. Rank the relative-abundance values across ALL samples (ties averaged).
##   2. Fit a two-way ANOVA on those ranks: rank ~ biotype * timepoint.
##   3. Convert each term's Sum Sq to an H statistic: H = SS_term / (SS_total/(N-1)).
##   4. H ~ chi-square(df_term) under the null.
## Note: with this unbalanced design (t0 has only 3 samples per biotype vs.
## ~50 for t2/t4/t8), Type I (sequential) sums of squares are order-dependent
## for the two main effects, but the interaction term -- entered last -- has
## the same SS regardless of main-effect order, so the interaction test below
## is not sensitive to this issue.

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

merged <- colSums(counts[c("Mortierella", "Mortierellaceae"), ])
counts <- counts[!(rownames(counts) %in% c("Mortierella", "Mortierellaceae")), ]
counts <- rbind(counts, "Mortierella+Mortierellaceae" = merged)

meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE,
                        stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
counts <- counts[, common_ids]
meta <- meta_raw[common_ids, ]
meta$biotype   <- factor(meta$biotype)
meta$timepoint <- factor(meta$timepoint)

sample_totals <- colSums(counts)
relabund <- sweep(counts, 2, sample_totals, "/")

x <- as.numeric(relabund["Mortierella+Mortierellaceae", ])
r <- rank(x)  # ties averaged

cat("Cell sizes (biotype x timepoint):\n")
print(table(meta$biotype, meta$timepoint))
cat("\n")

fit <- aov(r ~ meta$biotype * meta$timepoint)
tab <- summary(fit)[[1]]
print(tab)
cat("\n")

N <- length(r)
SS_total <- sum(tab[["Sum Sq"]])
MS_total <- SS_total / (N - 1)

terms <- rownames(tab)
terms <- terms[terms != "Residuals"]

cat("Scheirer-Ray-Hare results:\n")
results <- data.frame(term = character(), H = numeric(), df = numeric(), p_value = numeric())
for (term in terms) {
  SS <- tab[term, "Sum Sq"]
  df <- tab[term, "Df"]
  H <- SS / MS_total
  p <- pchisq(H, df, lower.tail = FALSE)
  results <- rbind(results, data.frame(term = trimws(term), H = H, df = df, p_value = p))
}
print(results, row.names = FALSE)

write.table(results, "gb18Sgenusmortierella_SRH_interaction.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)
