#!/usr/bin/perl
## Extract in-text reference citations from a manuscript text file and print
## them, deduplicated, in alphabetical order.
##
## Two passes per line:
##
## Pass A -- narrative citations, where the author name(s) sit outside any
## parentheses and are immediately followed by "(Year[list])":
##   Xu et al. (2025)
##   Lin and Pedada (2020)   /   Lin & Pedada (2020)
##   Anderson (2014)
##
## Pass B -- parenthetical citation clusters: one or more citations inside a
## single (...) span, each shaped "Name(s), Year" and separated by "; " if
## there is more than one member, e.g.:
##   (Xu et al., 2025)
##   (Barta & Cagan, 2006)
##   (Royer, 2023)
##   (Bolyen et al., 2019; Shannon, 1948; Pielou, 1966)
## Each ";"-delimited segment is *searched* rather than anchored, so a
## descriptive lead-in like "(Figure 2 of Silva et al., 2004)" still yields
## "Silva et al. (2004)".
##
## A same-author multi-year list in one set of parens, e.g. "Crane et al.
## (2025a, 2025b)" or "Crane et al. (2023 and 2025a)", is split into one
## citation entry per year. Author lists joined by "&" are normalized to
## "and" in the printed output (e.g. "(Barta & Cagan, 2006)" is printed as
## "Barta and Cagan (2006)") so equivalent citations from either style dedup
## together. The "et al." period and the comma before the year are both
## optional, so "(de Almeida et al. 2022)" and "(Madey et al, 2002)" (real
## inconsistencies found in this manuscript) are still caught.
##
## Known remaining limitation: parentheses are matched non-nested
## (\([^()]*\)), so a citation inside a nested parenthetical (as can happen
## inside a full bibliography entry) would not be extracted -- not an issue
## for in-text citations before the stopword cutoff, which is where this
## script stops reading.
##
## Collection stops at the first line whose trimmed content is exactly
## $stopword (a single word on its own line) -- typically "References" or
## "Disclosure" -- so the manuscript's own bibliography (full of
## "Author (Year)"-shaped text that is NOT an in-text citation) is never
## scanned.
##
## Usage: perl extract_citations0723.pl <input_file> [stopword]
##   stopword defaults to "References" if omitted.

use strict;
use warnings;
use utf8;
use open ':std', ':encoding(UTF-8)';

my ($infile, $stopword) = @ARGV;
die "Usage: perl extract_citations0723.pl <input_file> [stopword]\n"
    unless defined $infile;
$stopword = 'References' unless defined $stopword;

## Names like "O'Donnell" in this manuscript use a curly apostrophe (U+2019),
## which only matches $NAME's continuation class correctly if the file is
## decoded as UTF-8 -- otherwise its raw UTF-8 bytes break the match right
## after "O" and the citation is mis-captured as "Donnell et al. (1977)".
open(my $fh, '<:encoding(UTF-8)', $infile) or die "Cannot open $infile: $!\n";

my $NAME     = qr/[A-Z][A-Za-z'\x{2019}\-]+/;
my $YEAR     = qr/\d{4}[a-z]?/;
my $YEARLIST = qr/$YEAR(?:(?:,\s*|\s+and\s+)$YEAR)*/;
my $AND      = qr/(?:and|&)/;

my %seen;

LINE: while (my $line = <$fh>) {
    chomp $line;
    (my $trimmed = $line) =~ s/^\s+|\s+$//g;
    last LINE if $trimmed eq $stopword;

    ## ---- Pass A: narrative citations ----
    while ($line =~ m{
        ($NAME) \s+ et\ al\.? \s* \( ($YEARLIST) \)           # Xu et al. (2025) / Xu et al (2025)
      | ($NAME) \s+ $AND \s+ ($NAME) \s* \( ($YEARLIST) \)    # Lin and/& Pedada (2020)
      | ($NAME) \s* \( ($YEARLIST) \)                          # Anderson (2014)
    }gx) {
        if (defined $1) {
            record_years("$1 et al.", $2);
        } elsif (defined $3) {
            record_years("$3 and $4", $5);
        } elsif (defined $6) {
            record_years($6, $7);
        }
    }

    ## ---- Pass B: parenthetical citation clusters ----
    while ($line =~ /\(([^()]*)\)/g) {
        my $interior = $1;
        for my $segment (split /;\s*/, $interior) {
            if ($segment =~ /($NAME)\s+et\s+al\.?,?\s*($YEARLIST)/) {
                record_years("$1 et al.", $2);
            } elsif ($segment =~ /($NAME)\s+$AND\s+($NAME),\s*($YEARLIST)/) {
                record_years("$1 and $2", $3);
            } elsif ($segment =~ /($NAME),\s*($YEARLIST)/) {
                record_years($1, $2);
            }
        }
    }
}
close $fh;

sub record_years {
    my ($who, $yearlist) = @_;
    for my $year (split /\s*(?:,|and)\s*/, $yearlist) {
        next unless length $year;
        $seen{"$who ($year)"} = 1;
    }
}

print "$_\n" for sort keys %seen;
