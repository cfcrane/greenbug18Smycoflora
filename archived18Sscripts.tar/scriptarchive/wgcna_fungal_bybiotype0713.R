## WGCNA co-abundance network for the fungal (18S) genus table, run
## SEPARATELY within biotype E and biotype K, to test whether module
## structure is masked in the pooled (all-sample) network by taxa that
## are gated in opposite directions by host biotype (see gb18Sgenuskruskal*
## results: many bimodal genera split E-high vs K-high).
##
## Filtering + CLR convention matches correlate_bact_fung.R (min_prev=3,
## min_count=10 raw-count prevalence filter; CLR = log(x+pc) - colMean(log(x+pc)),
## pc=0.5) so results are comparable to the rest of this project's pipeline.

suppressMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

## Same merge used throughout this session's genus-level analyses
merged <- colSums(counts[c("Mortierella", "Mortierellaceae"), ])
counts <- counts[!(rownames(counts) %in% c("Mortierella", "Mortierellaceae")), ]
counts <- rbind(counts, "Mortierella+Mortierellaceae" = merged)

meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE,
                        stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
counts <- counts[, common_ids]
meta <- meta_raw[common_ids, ]
meta$biotype <- factor(meta$biotype)

filter_taxa <- function(mat, min_prev = 3, min_count = 10) {
  keep <- rowSums(mat >= min_count) >= min_prev
  mat[keep, , drop = FALSE]
}
clr_transform <- function(mat, pc = 0.5) {
  lg <- log(mat + pc)
  sweep(lg, 2, colMeans(lg), "-")
}

genera_of_interest <- c("Mortierella+Mortierellaceae", "Simplicillium",
                         "Capnodiales_gen_Incertae_sedis", "Fusarium", "Wallemia",
                         "Protista_gen_Incertae_sedis",
                         "Debaryomycetaceae_gen_Incertae_sedis", "Arthrobotrys")

run_wgcna_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- rownames(meta)[meta$biotype == bt]
  mat <- counts[, ids]

  mat_f <- filter_taxa(mat, min_prev = 3, min_count = 10)
  cat("Taxa kept after prevalence filter:", nrow(mat_f), "of", nrow(mat), "\n")
  cat("Samples:", ncol(mat_f), "\n")

  clr <- clr_transform(mat_f, pc = 0.5)
  datExpr <- t(clr)   # WGCNA wants samples x taxa

  gsg <- goodSamplesGenes(datExpr, verbose = 0)
  if (!gsg$allOK) {
    cat("Removing", sum(!gsg$goodGenes), "taxa and", sum(!gsg$goodSamples),
        "samples flagged by goodSamplesGenes\n")
    datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]
  }

  powers <- c(1:20)
  sft <- pickSoftThreshold(datExpr, powerVector = powers, networkType = "signed",
                            verbose = 0)
  chosen_power <- sft$powerEstimate
  if (is.na(chosen_power)) {
    ## fallback: power achieving the BEST observed R^2 in the tested range
    ## (NOT the largest power -- a high power with poor fit just collapses
    ## connectivity to ~0 and trivially yields a single grey module).
    chosen_power <- sft$fitIndices$Power[which.max(sft$fitIndices[, "SFT.R.sq"])]
  }
  cat("Soft-threshold power chosen:", chosen_power,
      sprintf("(scale-free R^2 = %.2f at that power)\n",
              sft$fitIndices$SFT.R.sq[sft$fitIndices$Power == chosen_power]))

  net <- blockwiseModules(datExpr, power = chosen_power, networkType = "signed",
                           TOMType = "signed", minModuleSize = 10,
                           mergeCutHeight = 0.25, numericLabels = TRUE,
                           saveTOMs = FALSE, verbose = 0)

  moduleColors <- labels2colors(net$colors)
  names(moduleColors) <- colnames(datExpr)

  sizes <- sort(table(moduleColors), decreasing = TRUE)
  cat("\nModule sizes (", length(sizes), "modules incl. 'grey' = unassigned):\n", sep = "")
  print(sizes)

  cat("\nModule membership of taxa of interest:\n")
  for (g in genera_of_interest) {
    col <- if (g %in% names(moduleColors)) moduleColors[[g]] else "NOT IN NETWORK (filtered out)"
    cat(sprintf("  %-40s %s\n", g, col))
  }

  out <- data.frame(genus = names(moduleColors), module = moduleColors)
  out <- out[order(out$module), ]
  fname <- paste0("gb18Sfungwgcna_biotype", bt, "_modules.txt")
  write.table(out, fname, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("\nWritten:", fname, "\n")

  invisible(list(moduleColors = moduleColors, net = net, power = chosen_power))
}

resE <- run_wgcna_for_biotype("E")
resK <- run_wgcna_for_biotype("K")
