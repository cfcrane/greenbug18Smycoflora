## NMDS ordination of a QIIME2 Bray-Curtis distance matrix (*_distance_matrix.qza),
## with group ellipses, stress reported on the plot, and the companion tests a
## bare ordination is missing: PERMANOVA (adonis2) for group separation and
## PERMDISP (betadisper) to check that isn't just a dispersion difference.
##
## NMDS (not PCoA) is used deliberately: Bray-Curtis is a semi-metric (violates
## the triangle inequality), and NMDS's rank-based approach suits that better
## than PCoA, which can produce negative eigenvalues on semi-metric distances.
## The stress value reported here indicates how well the 2D layout preserves
## the original rank-order distances (conventionally: <0.1 excellent, <0.2 fair,
## >0.3 unreliable).
##
## *_distance_matrix.qza is a zip archive; the actual matrix lives at
## <uuid>/data/distance-matrix.tsv inside it, extracted here directly (no
## qiime2R dependency needed for this one file type).

## ---- CONFIG ----
distance_matrix_qza <- "K_bray_curtis_distance_matrix.qza"
metadata_file        <- "metadataforbiotypeK0715.txt"
sample_id_col        <- "ID"           # column in metadata_file holding sample IDs
group_var             <- "timepoint" # metadata column to compare/color groups by
n_permutations        <- 4999            # for adonis2 / permutest
out_prefix            <- "K_bray_curtis_NMDS_fortimepoint"
seed                  <- 11279929              # for reproducible metaMDS random starts
## -----------------

pkgs <- c("vegan", "ggplot2", "svglite")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")

suppressMessages({
  library(vegan)
  library(ggplot2)
})

## Extract data/distance-matrix.tsv from the .qza (a zip archive) and load it
read_qza_distance <- function(path) {
  entries <- unzip(path, list = TRUE)$Name
  dm_entry <- entries[grepl("data/distance-matrix\\.tsv$", entries)]
  if (length(dm_entry) != 1) {
    stop("Expected exactly one data/distance-matrix.tsv inside ", path,
         ", found ", length(dm_entry))
  }
  tmp_dir <- tempfile("qza_")
  dir.create(tmp_dir)
  unzip(path, files = dm_entry, exdir = tmp_dir)
  dm <- read.delim(file.path(tmp_dir, dm_entry), row.names = 1, check.names = FALSE)
  unlink(tmp_dir, recursive = TRUE)
  as.dist(as.matrix(dm))
}

cat("Reading distance matrix:", distance_matrix_qza, "\n")
dm <- read_qza_distance(distance_matrix_qza)
dist_labels <- attr(dm, "Labels")
cat(sprintf("Loaded a %d-sample Bray-Curtis distance matrix.\n", length(dist_labels)))

meta <- read.delim(metadata_file, check.names = FALSE, stringsAsFactors = FALSE)
meta <- meta[meta[[sample_id_col]] != "#q2:types", ]  # drop QIIME2 metadata type-declaration row, if present
names(meta)[names(meta) == sample_id_col] <- "sample_id"

## Align metadata to the distance matrix's own sample order (required by adonis2/betadisper)
meta_sub <- meta[match(dist_labels, meta$sample_id), ]
unmatched <- dist_labels[is.na(meta_sub$sample_id)]
if (length(unmatched) > 0) {
  stop("Distance-matrix sample(s) not found in metadata: ", paste(unmatched, collapse = ", "))
}
meta_sub[[group_var]] <- factor(meta_sub[[group_var]])

cat(sprintf("Matched %d samples across %d levels of '%s'\n",
            nrow(meta_sub), nlevels(meta_sub[[group_var]]), group_var))

## ---- NMDS ----
set.seed(seed)
ord <- metaMDS(dm, k = 3, trymax = 5000, trace = FALSE)
cat(sprintf("\nNMDS stress = %.4f (k=2)\n", ord$stress))

scores_df <- as.data.frame(scores(ord, display = "sites"))
scores_df$sample_id <- rownames(scores_df)
scores_df[[group_var]] <- meta_sub[[group_var]][match(scores_df$sample_id, meta_sub$sample_id)]

write.table(scores_df, paste0(out_prefix, "_scores.txt"), sep = "\t", quote = FALSE, row.names = FALSE)
cat("Written:", paste0(out_prefix, "_scores.txt"), "\n")

## ---- PERMANOVA (on the full distance matrix, not the 2D ordination) ----
form <- as.formula(paste("dm ~", group_var))
permanova <- adonis2(form, data = meta_sub, permutations = n_permutations)
cat("\nPERMANOVA (adonis2):\n")
print(permanova)
write.table(as.data.frame(permanova), paste0(out_prefix, "_permanova.txt"),
            sep = "\t", quote = FALSE, col.names = NA)

## ---- PERMDISP (checks PERMANOVA "significance" isn't just a dispersion effect) ----
bd <- betadisper(dm, meta_sub[[group_var]])
permdisp <- permutest(bd, permutations = n_permutations)
cat("\nPERMDISP (betadisper + permutest):\n")
print(permdisp)
write.table(as.data.frame(permdisp$tab), paste0(out_prefix, "_permdisp.txt"),
            sep = "\t", quote = FALSE, col.names = NA)

cat("\nWritten:", paste0(out_prefix, "_permanova.txt"), "/", paste0(out_prefix, "_permdisp.txt"), "\n")

## ---- Plot: NMDS ordination with group ellipses and stress annotated ----
stress_label <- sprintf("Stress = %.3f", ord$stress)

p <- ggplot(scores_df, aes(x = NMDS1, y = NMDS2, color = .data[[group_var]])) +
  geom_point(size = 2, alpha = 0.8) +
  stat_ellipse(type = "t", linewidth = 0.6) +
  annotate("text", x = -Inf, y = -Inf, label = stress_label,
           hjust = -0.1, vjust = -0.6, size = 4) +
  labs(x = "NMDS1", y = "NMDS2", color = group_var) +
  theme_bw(base_size = 12) +
  coord_equal()

for (fmt in c("pdf", "svg")) {
  ggsave(paste0(out_prefix, ".", fmt), p, width = 6, height = 5)
}

cat("\nWritten figure:", paste0(out_prefix, ".{pdf,svg}"), "\n")
