## Three-factor PERMANOVA ranking the effects of biotype, host_species, and
## timepoint (t0 excluded) on fungal 18S community composition, starting from
## fung_genus_forbiom.txt (genus x sample raw counts, both biotypes combined
## in one table) rather than a QIIME2 Bray-Curtis .qza -- because this
## analysis needs a Bray-Curtis matrix built AFTER rarefaction to a common
## depth, and the existing *_bray_curtis_distance_matrix.qza files were each
## built (and separately rarefied, if at all) per biotype.
##
## Full factorial model: dm ~ biotype * host_species * timepoint
## adonis2's `*` expands to all 3 main effects + all 3 two-way interactions +
## the one three-way interaction = 7 terms, of which 4 are interactions
## (biotype:host_species, biotype:timepoint, host_species:timepoint,
## biotype:host_species:timepoint).
##
## Two sequential (by = "terms") partitions are run and written, not just one:
##  - the requested order: biotype, host_species, timepoint. With unbalanced
##    data (see below), sequential SS gives each earlier main effect first
##    claim on any variance it shares with later ones, so main-effect and
##    two-way-interaction R2/F values below depend on this particular order.
##  - the fully reversed order: timepoint, host_species, biotype -- run so
##    the requested order's headline result (biotype's effect dwarfing the
##    others) can be checked for robustness: does biotype still dominate even
##    when tested LAST, after timepoint and host_species have already claimed
##    any variance they share with it? (The three-way interaction's row is
##    identical in both, since it is always fit last regardless of order.)
##
## by = "margin" (marginal/Type III-style SS, order-invariant) was NOT used
## for the full model: vegan's adonis2 restricts marginal testing to terms
## that respect marginality (a term can only be tested this way if it isn't
## contained in some higher-order term still in the model). In a fully
## saturated three-way factorial that leaves exactly one testable term -- the
## three-way interaction itself -- which is already identical to that term's
## row in both sequential tables above, so a separate by="margin" run adds
## no new information here; it's a real property of the saturated design, not
## a bug (confirmed against a small toy 3-factor dataset before writing this).
##
## Rarefaction: every sample is rarefied (via vegan::rrarefy) to exactly
## `rarefaction_depth` counts before the Bray-Curtis matrix is built, so
## differences in sequencing depth across samples/treatments can't masquerade
## as compositional differences. Samples with fewer raw counts than the
## requested depth cannot be rarefied up and are dropped (reported by name).

## ---- CONFIG ----
counts_file          <- "fung_genus_forbiom.txt"
metadata_files       <- c("metadataforbiotypeE0715.txt", "metadataforbiotypeK0715.txt")
sample_id_col        <- "ID"
biotype_var          <- "biotype"
species_var          <- "host_cultivar"
timepoint_var        <- "timepoint"
timepoint_levels_to_drop <- c("t0")   # e.g. c("t0"); use character(0) to keep all timepoints
rarefaction_depth   <- 25670          # user-specified common sequencing depth
n_permutations       <- 4999
out_prefix           <- "threefactor_biotype_species_timepoint0721a"
seed                 <- 11279929      # for reproducible rarefaction draw AND permutation p-values
## -----------------

if (length(timepoint_levels_to_drop) > 0) {
  out_prefix <- paste0(out_prefix, "_excl_", paste(timepoint_levels_to_drop, collapse = ""))
}
out_prefix <- paste0(out_prefix, "_rar", rarefaction_depth)

pkgs <- c("vegan")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
suppressMessages(library(vegan))

## ---- Load genus x sample counts (both biotypes combined) ----
cat("Reading counts:", counts_file, "\n")
counts <- read.delim(counts_file, check.names = FALSE, row.names = 1)
cat(sprintf("Loaded %d genera x %d samples.\n", nrow(counts), ncol(counts)))

## ---- Load and combine metadata from both biotypes ----
meta_list <- lapply(metadata_files, function(f) {
  m <- read.delim(f, check.names = FALSE, stringsAsFactors = FALSE)
  m[m[[sample_id_col]] != "#q2:types", ]  # drop QIIME2 metadata type-declaration row, if present
})
meta <- do.call(rbind, meta_list)
names(meta)[names(meta) == sample_id_col] <- "sample_id"
cat(sprintf("Combined metadata: %d samples across %d file(s).\n", nrow(meta), length(metadata_files)))

dup_ids <- meta$sample_id[duplicated(meta$sample_id)]
if (length(dup_ids) > 0) {
  stop("Duplicate sample_id(s) across metadata files: ", paste(unique(dup_ids), collapse = ", "))
}

unmatched_counts <- setdiff(colnames(counts), meta$sample_id)
unmatched_meta   <- setdiff(meta$sample_id, colnames(counts))
if (length(unmatched_counts) > 0) {
  stop("Sample(s) in ", counts_file, " not found in metadata: ", paste(unmatched_counts, collapse = ", "))
}
if (length(unmatched_meta) > 0) {
  stop("Sample(s) in metadata not found in ", counts_file, ": ", paste(unmatched_meta, collapse = ", "))
}

## ---- Drop timepoint level(s), e.g. t0 ----
if (length(timepoint_levels_to_drop) > 0) {
  keep <- !(meta[[timepoint_var]] %in% timepoint_levels_to_drop)
  cat(sprintf("\nDropping timepoint level(s) %s: removing %d of %d samples.\n",
              paste(timepoint_levels_to_drop, collapse = ", "), sum(!keep), length(keep)))
  meta <- meta[keep, ]
}
counts <- counts[, meta$sample_id, drop = FALSE]  # align column order to meta's row order

## ---- Rarefy every remaining sample to a common depth ----
depths <- colSums(counts)
too_shallow <- names(depths)[depths < rarefaction_depth]
if (length(too_shallow) > 0) {
  cat(sprintf("\nDropping %d sample(s) below rarefaction depth %d: %s\n",
              length(too_shallow), rarefaction_depth, paste(too_shallow, collapse = ", ")))
  counts <- counts[, setdiff(colnames(counts), too_shallow), drop = FALSE]
  meta   <- meta[meta$sample_id %in% colnames(counts), ]
}
counts <- counts[, meta$sample_id, drop = FALSE]  # re-align after any drops

cat(sprintf("Rarefying %d samples to %d counts each (seed = %d)...\n",
            ncol(counts), rarefaction_depth, seed))
set.seed(seed)
rarefied <- rrarefy(t(counts), sample = rarefaction_depth)  # rrarefy expects samples as rows

## ---- Bray-Curtis distance on the rarefied community table ----
dm <- vegdist(rarefied, method = "bray")
cat(sprintf("Built a %d-sample Bray-Curtis distance matrix from rarefied counts.\n", nrow(rarefied)))

## `dm`'s row order (from `rarefied`, which came from t(counts)) must match
## `meta`'s row order for adonis2 -- both were built from the same
## meta$sample_id-ordered `counts`, so they already agree; assert it anyway.
stopifnot(identical(labels(dm), meta$sample_id))

meta[[biotype_var]]   <- factor(meta[[biotype_var]])
meta[[species_var]]   <- factor(meta[[species_var]])
meta[[timepoint_var]] <- factor(meta[[timepoint_var]])

cat(sprintf("\nFactor levels: %d %s, %d %s, %d %s\n",
            nlevels(meta[[biotype_var]]), biotype_var,
            nlevels(meta[[species_var]]), species_var,
            nlevels(meta[[timepoint_var]]), timepoint_var))

## ---- Balance diagnostics (3-way cross-tab) ----
cat("\n==== biotype x host_species x timepoint cross-tabulation ====\n")
tab3 <- table(meta[[biotype_var]], meta[[species_var]], meta[[timepoint_var]])
print(tab3)
zero_cells <- sum(tab3 == 0)
filled <- tab3[tab3 > 0]
cat(sprintf("\n%d of %d factor-combination cells are empty; filled-cell sizes range from %d to %d.\n",
            zero_cells, length(tab3), min(filled), max(filled)))
unbalanced <- (zero_cells > 0 || length(unique(filled)) > 1)
if (unbalanced) {
  cat("-> UNBALANCED design: sequential (by=\"terms\") main-effect/interaction SS below\n",
      "   are order-dependent; the reversed-order run afterwards checks robustness.\n", sep = "")
} else {
  cat("-> BALANCED design: term order should not matter.\n")
}

## ---- Full factorial three-factor PERMANOVA (sequential SS) ----
run_permanova <- function(vars, suffix, label) {
  form <- as.formula(paste("dm ~", paste(vars, collapse = " * ")))
  cat(sprintf("\n---- PERMANOVA (%s) ----\n", label))
  set.seed(seed)
  res <- adonis2(form, data = meta, permutations = n_permutations, by = "terms")
  print(res)
  fname <- paste0(out_prefix, "_permanova_", suffix, ".txt")
  write.table(as.data.frame(res), fname, sep = "\t", quote = FALSE, col.names = NA)
  cat("Written:", fname, "\n")
  invisible(res)
}

run_permanova(c(biotype_var, species_var, timepoint_var), "seq_biotype_species_timepoint",
              "sequential, order = biotype, host_species, timepoint (as requested)")

if (unbalanced) {
  run_permanova(c(timepoint_var, species_var, biotype_var), "seq_timepoint_species_biotype",
                "sequential, REVERSED order = timepoint, host_species, biotype")
  cat("(Design is unbalanced, so the reversed order was also run -- compare each\n",
      "main effect's R2/F across the two tables; the three-way interaction row\n",
      "is identical in both since it is always fit last.)\n", sep = "")
}

cat("\nDone.\n")
