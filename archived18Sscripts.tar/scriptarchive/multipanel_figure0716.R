## Assembles a multipanel figure from a list of panel image files (svg/pdf/png),
## arranged left-to-right, top-to-bottom in a 2-column grid:
##   1st file -> upper left     2nd file -> upper right
##   3rd file -> center left    4th file -> center right
##   5th file -> lower left     6th file -> lower right
## Accepts 4-6 panel files. Saves the composite as PDF, SVG, and PNG.
##
## SVG is the recommended input format: it is re-rasterized here at high
## resolution rather than passed through Ghostscript (as PDF import requires),
## which avoids font/glyph issues sometimes seen importing ggplot2 PDFs.
## Note: the outputs below are a high-DPI raster composite (each panel is
## rasterized before assembly) -- panels are not separately vector-editable
## in the saved PDF/SVG. If you need true vector recombination (e.g. to edit
## a single panel's colors in Illustrator afterward), ask for the grImport2-
## based alternative; it's more fragile since SVG renderer feature support
## varies, so it isn't the default here.

## ---- CONFIG ----
panel_list_file <- "panel_list.txt"   # one panel file path per line, in panel order
out_prefix      <- "multipanel_figure"
render_px       <- 2400               # width (px) used to rasterize each SVG panel
pdf_density     <- 300                # dpi used to rasterize each PDF panel
panel_labels     <- LETTERS   # A, B, C, ... one per panel, in panel order
label_margin_frac <- 0.12     # blank strip added above each panel to hold its label, as a fraction of panel height
label_size_frac   <- 0.35     # label font size, as a fraction of that margin strip's height
label_inset_frac  <- 0.1      # label inset from the strip's top-left corner, as a fraction of the strip's height
## -----------------

pkgs <- c("magick")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
library(magick)

panel_files <- trimws(readLines(panel_list_file))
panel_files <- panel_files[nchar(panel_files) > 0]

if (length(panel_files) < 4 || length(panel_files) > 6) {
  stop(sprintf("Expected 4-6 panel files in %s, found %d", panel_list_file, length(panel_files)))
}
missing <- panel_files[!file.exists(panel_files)]
if (length(missing) > 0) stop("Panel file(s) not found: ", paste(missing, collapse = ", "))

read_panel <- function(path) {
  ext <- tolower(tools::file_ext(path))
  if (ext == "pdf") {
    image_read_pdf(path, density = pdf_density)
  } else if (ext == "svg") {
    image_read_svg(path, width = render_px)
  } else {
    image_read(path)
  }
}

cat(sprintf("Reading %d panels:\n%s\n", length(panel_files), paste(" -", panel_files, collapse = "\n")))
imgs <- lapply(panel_files, read_panel)

## Normalize all panels to a common height (preserving aspect ratio) so rows align
heights <- sapply(imgs, function(im) image_info(im)$height)
target_h <- max(heights)
imgs <- lapply(imgs, function(im) image_resize(im, paste0("x", target_h)))

## Add a blank margin strip above each panel and stamp the label there, so it
## never overlaps plot content (e.g. a rotated y-axis title sitting at the
## panel's top-left corner)
margin_px <- round(label_margin_frac * target_h)
imgs <- lapply(imgs, function(im) {
  info <- image_info(im)
  image_extent(im, geometry = sprintf("%dx%d", info$width, info$height + margin_px),
               gravity = "south", color = "white")
})
target_h <- target_h + margin_px

label_size <- round(label_size_frac * margin_px)
label_inset <- round(label_inset_frac * margin_px)
imgs <- Map(function(im, lbl) {
  image_annotate(im, lbl, gravity = "northwest",
                  location = sprintf("+%d+%d", label_inset, label_inset),
                  size = label_size, weight = 700, color = "black")
}, imgs, panel_labels[seq_along(imgs)])

n <- length(imgs)
ncol_grid <- 2
nrow_grid <- ceiling(n / ncol_grid)

## Pad to a full grid with a blank panel if the count is odd, for regular montage geometry
if (n %% ncol_grid != 0) {
  widths <- sapply(imgs, function(im) image_info(im)$width)
  blank <- image_blank(width = max(widths), height = target_h, color = "white")
  imgs <- c(imgs, list(blank))
}

widths <- sapply(imgs, function(im) image_info(im)$width)
tile_geometry <- sprintf("%dx%d+10+10", max(widths), target_h)

panel_stack <- image_join(imgs)
composite <- image_montage(panel_stack,
                            tile = sprintf("%dx%d", ncol_grid, nrow_grid),
                            geometry = tile_geometry,
                            bg = "white")

image_write(composite, paste0(out_prefix, ".png"), format = "png")
image_write(composite, paste0(out_prefix, ".pdf"), format = "pdf")
image_write(composite, paste0(out_prefix, ".svg"), format = "svg")

cat(sprintf("\nWritten: %s.{png,pdf,svg}\n", out_prefix))
