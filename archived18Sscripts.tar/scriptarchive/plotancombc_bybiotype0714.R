## Bar-plot figure of ANCOM-BC2 genus-level differential abundance by
## timepoint (t2/t4/t8 vs. t0 reference), restricted to biotype K -- the
## only biotype with genera passing q < 0.05 (see ancombc_bybiotype0714.R;
## biotype E had zero significant genera at any timepoint contrast, closest
## was Hansfordia q=0.051 at t2, so no comparable figure was produced for E).
##
## Style matches the existing published figure
## gb18Sqfildeblurredcounts1119mcraref25750_ancombcbarplots.svg (panels B-D):
## horizontal bars sorted by log fold change, blue = higher at the later
## timepoint, orange = higher at day 0, whiskers = LFC +/- SE, genus labels
## on the y-axis, x-axis = "Log Fold Change (LFC)".

out <- readRDS("gb18Sfungancombc_biotypeK_timepoint.rds")
res <- out$res

col_up   <- "#2a78d6"  # blue   -- higher at later timepoint
col_down <- "#eda100"  # orange -- higher at day 0

get_panel_data <- function(tp) {
  lfc_col <- paste0("lfc_timepoint", tp)
  se_col  <- paste0("se_timepoint", tp)
  sig_col <- paste0("diff_robust_timepoint", tp)
  sig <- res[[sig_col]] & !is.na(res[[sig_col]])
  d <- data.frame(taxon = res$taxon[sig],
                   lfc = res[[lfc_col]][sig],
                   se  = res[[se_col]][sig])
  d[order(d$lfc), ]  # ascending so barplot() draws largest at top
}

panels <- list(t2 = get_panel_data("t2"),
               t4 = get_panel_data("t4"),
               t8 = get_panel_data("t8"))
titles <- c(t2 = "day 2 vs. day 0", t4 = "day 4 vs. day 0", t8 = "day 8 vs. day 0")

plot_panel <- function(d, title, tp_label) {
  n <- nrow(d)
  cols <- ifelse(d$lfc > 0, col_up, col_down)
  xr <- range(c(d$lfc - d$se, d$lfc + d$se))
  xr <- xr + c(-0.3, 0.35) * diff(xr)

  bp <- barplot(d$lfc, horiz = TRUE, col = cols, border = NA,
                xlim = xr, xlab = "Log Fold Change (LFC)",
                names.arg = d$taxon, las = 1, cex.names = 0.75,
                main = title, font.main = 1, cex.main = 1.05)
  segments(d$lfc - d$se, bp, d$lfc + d$se, bp, lwd = 1)
  segments(d$lfc - d$se, bp - 0.15, d$lfc - d$se, bp + 0.15, lwd = 1)
  segments(d$lfc + d$se, bp - 0.15, d$lfc + d$se, bp + 0.15, lwd = 1)
  abline(v = 0, col = "grey40", lwd = 0.8)

  legend("topleft", legend = c(paste("More at", tp_label), "More at day 0"),
         fill = c(col_up, col_down), text.col = "black", bty = "n", cex = 0.85)
}

tp_labels <- c(t2 = "day 2", t4 = "day 4", t8 = "day 8")

## Give each panel a share of the figure's vertical space proportional to
## its bar count (plus a fixed allowance for the title/x-axis margins) so
## that individual bar heights come out equal across all three panels,
## instead of every panel getting an equal share and the t8 panel's fewer
## bars stretching to fill it.
margin_units <- 5
n_bars <- c(t2 = nrow(panels$t2), t4 = nrow(panels$t4), t8 = nrow(panels$t8))
panel_units <- n_bars + margin_units
in_per_unit <- 4 / panel_units[["t2"]]   # calibrated to the original t2 panel height
panel_heights_in <- panel_units * in_per_unit
fig_height <- sum(panel_heights_in)

plot_all <- function() {
  layout(matrix(1:3, ncol = 1), heights = panel_units)
  par(mar = c(4, 13, 2.2, 1))
  for (tp in names(panels)) {
    plot_panel(panels[[tp]], titles[[tp]], tp_labels[[tp]])
  }
}

pdf("gb18Sfungancombc_biotypeK_timepoint_barplots.pdf", width = 8, height = fig_height)
plot_all()
dev.off()
svg("gb18Sfungancombc_biotypeK_timepoint_barplots.svg", width = 8, height = fig_height)
plot_all()
dev.off()
png("gb18Sfungancombc_biotypeK_timepoint_barplots.png", width = 8, height = fig_height, units = "in", res = 600)
plot_all()
dev.off()

cat("Written: gb18Sfungancombc_biotypeK_timepoint_barplots.pdf / .svg / .png\n")
cat("Panel sizes: t2 =", nrow(panels$t2), " t4 =", nrow(panels$t4), " t8 =", nrow(panels$t8), "genera\n")
