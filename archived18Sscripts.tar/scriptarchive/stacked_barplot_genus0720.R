## Stacked barplot of relative abundance for the N most abundant genera,
## across the 3 replicate samples of one treatment (e.g. KB1-11/-12/-13).
##
## Input: a genus x sample count table in the same format as
## fung_genus_forbiom.txt -- tab-delimited, first column genus names, the
## rest raw counts per sample. Relative abundance (%) is computed per sample
## (column-normalized), then the top N genera are chosen by MEAN relative
## abundance ACROSS the 3 replicates (not independently per replicate) -- so
## the same N genera, and the same fill color, represent the same taxon in
## all three bars, keeping the stacks visually comparable across replicates.
## Everything outside the top N is summed into "All other (rarer) genera"
## per replicate.

## ---- CONFIG ----
counts_file     <- "fung_genus_forbiom.txt"
replicates      <- c("KB3-11", "KB3-12", "KB3-13")   # exactly 3 sample IDs (column names in counts_file)
treatment_label <- "KB3"
top_n           <- 10
out_prefix      <- paste0("gb18Sgenus_top", top_n, "_", treatment_label, "reps0720")
## -----------------

pkgs <- c("ggplot2", "svglite", "RColorBrewer")
missing_pkgs <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
if (length(missing_pkgs) > 0) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
library(ggplot2)

counts <- read.delim(counts_file, check.names = FALSE, row.names = 1)

if (length(replicates) != 3) stop("`replicates` must list exactly 3 sample IDs.")
missing_reps <- setdiff(replicates, colnames(counts))
if (length(missing_reps) > 0) {
  stop("Replicate(s) not found in ", counts_file, ": ", paste(missing_reps, collapse = ", "))
}

sub_counts   <- counts[, replicates, drop = FALSE]
relabund_pct <- sweep(sub_counts, 2, colSums(sub_counts), "/") * 100

## Rank genera by MEAN relative abundance across the 3 replicates, so the
## same top-N set (and fill color) applies consistently to all three bars
mean_abund    <- rowMeans(relabund_pct)
ranked_genera <- names(sort(mean_abund, decreasing = TRUE))
top_genera    <- head(ranked_genera, top_n)

other_label <- "All other (rarer) genera"
other_row   <- colSums(relabund_pct[setdiff(rownames(relabund_pct), top_genera), , drop = FALSE])

top_df <- relabund_pct[top_genera, , drop = FALSE]
top_df <- rbind(top_df, setNames(data.frame(t(other_row)), replicates))
rownames(top_df)[nrow(top_df)] <- other_label

## Long format (replicate, genus, relative_abundance_pct), matching this
## project's established table convention
long_df <- data.frame(
  replicate = rep(colnames(top_df), each = nrow(top_df)),
  genus     = rep(rownames(top_df), times = ncol(top_df)),
  relative_abundance_pct = unlist(top_df, use.names = FALSE),
  stringsAsFactors = FALSE
)

genus_levels <- c(top_genera, other_label)
long_df$genus     <- factor(long_df$genus, levels = genus_levels)
long_df$replicate <- factor(long_df$replicate, levels = replicates)

write.table(long_df, paste0(out_prefix, ".txt"), sep = "\t", quote = FALSE, row.names = FALSE)
cat("Written:", paste0(out_prefix, ".txt"), "\n")

## ---- Plot ----
fill_colors <- c(colorRampPalette(RColorBrewer::brewer.pal(12, "Paired"))(top_n), "grey70")
names(fill_colors) <- genus_levels

p <- ggplot(long_df, aes(x = replicate, y = relative_abundance_pct, fill = genus)) +
  geom_col(width = 0.6, color = "white", linewidth = 0.15) +
  scale_fill_manual(values = fill_colors) +
  labs(x = treatment_label, y = "Relative abundance (%)", fill = "Genus") +
  theme_bw(base_size = 12)

for (fmt in c("pdf", "svg", "png")) {
  ggsave(paste0(out_prefix, ".", fmt), p, width = 5, height = 5.5, dpi = 300)
}

cat("Written figure:", paste0(out_prefix, ".{pdf,svg,png}"), "\n")
