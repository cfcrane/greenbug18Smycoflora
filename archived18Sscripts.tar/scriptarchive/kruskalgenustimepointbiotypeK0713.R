## Genus-level Kruskal-Wallis test by timepoint, restricted to biotype K samples only.
## Same merge (Mortierella + Mortierellaceae) and BH-correction convention as
## kruskalgenusbiotypetimepoint0713.R, but the timepoint test is run only on the
## biotype-K subset to check for a within-biotype temporal buildup that the
## marginal (all-biotype) test would dilute.

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

merged <- colSums(counts[c("Mortierella", "Mortierellaceae"), ])
counts <- counts[!(rownames(counts) %in% c("Mortierella", "Mortierellaceae")), ]
counts <- rbind(counts, "Mortierella+Mortierellaceae" = merged)

meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE,
                        stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
counts <- counts[, common_ids]
meta <- meta_raw[common_ids, ]
meta$biotype   <- factor(meta$biotype)
meta$timepoint <- factor(meta$timepoint)

## Restrict to biotype K
k_ids <- rownames(meta)[meta$biotype == "K"]
counts_k <- counts[, k_ids]
meta_k <- meta[k_ids, ]
meta_k$timepoint <- factor(meta_k$timepoint)

cat("Biotype K samples used:", length(k_ids), "\n")
cat("Timepoint distribution within biotype K:\n")
print(table(meta_k$timepoint))
cat("\n")

sample_totals <- colSums(counts_k)
relabund <- sweep(counts_k, 2, sample_totals, "/")

genera <- rownames(relabund)
n <- length(genera)

H_tp <- p_tp <- rep(NA_real_, n)

for (i in seq_len(n)) {
  x <- as.numeric(relabund[i, ])
  tp <- tryCatch(kruskal.test(x ~ meta_k$timepoint), error = function(e) NULL)
  if (!is.null(tp)) { H_tp[i] <- unname(tp$statistic); p_tp[i] <- tp$p.value }
}

q_tp <- p.adjust(p_tp, method = "BH")

res_timepoint_k <- data.frame(genus = genera, H = H_tp, p_value = p_tp, q_value = q_tp)
res_timepoint_k <- res_timepoint_k[order(res_timepoint_k$q_value), ]

write.table(res_timepoint_k, "gb18Sgenuskruskaltimepoint_biotypeK.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)

cat("Timepoint test (biotype K only):", sum(q_tp < 0.05, na.rm = TRUE),
    "of", n, "genera significant at q < 0.05\n\n")

cat("Top 20 genera by timepoint q-value (biotype K only):\n")
print(head(res_timepoint_k, 20), row.names = FALSE)

cat("\nMortierella+Mortierellaceae result within biotype K:\n")
print(res_timepoint_k[res_timepoint_k$genus == "Mortierella+Mortierellaceae", ], row.names = FALSE)
