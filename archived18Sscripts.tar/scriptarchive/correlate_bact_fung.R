#!/usr/bin/env Rscript
# correlate_bact_fung.R
#
# Correlate fungal-taxon abundance against bacterial-taxon abundance from two
# count tables (taxa in rows, samples in columns) that share sample ids.
#
# Pipeline (per the agreed compositional-data workflow):
#   1. read both tables, restrict to samples present in BOTH
#   2. drop rare taxa (prevalence + min-count filter), independently per table
#   3. centered-log-ratio (CLR) transform EACH table independently
#      (per-sample composition across taxa, with a pseudocount)
#   4. correlate CLR taxon-vectors across the common samples
#      - Pearson on CLR (default; approximates proportionality), or Spearman
#      - optional covariate adjustment => partial correlation, by residualizing
#        each taxon's CLR vector on covariates derived from the sample id
#        (biotype, species, cultivar, timepoint) before correlating
#   5. Benjamini-Hochberg FDR across the tested set (for the "all" modes)
#
# Three query modes:
#   f1b1    one fungal vs one bacterial   (needs --fungal AND --bacterial)
#   f1ball  one fungal vs ALL bacterial   (needs --fungal)
#   b1fall  one bacterial vs ALL fungal   (needs --bacterial)
#   allall  ALL fungal vs ALL bacterial   (full matrix; BH-FDR across all pairs)
#
# Usage:
#   Rscript correlate_bact_fung.R --bact bact_relabeled.txt \
#       --fung gb18Sqfildeblurredcounts1119condgenuscounts0110.txt \
#       --mode f1ball --fungal "d__Fungi;p__Ascomycota;..." \
#       [--bacterial "Pseudomonas"] [--method pearson|spearman] \
#       [--adjust timepoint,cultivar] [--min-prev 3] [--min-count 10] \
#       [--pseudocount 0.5] [--match exact|substr] [--out results.txt]
#
#   # list available taxon labels:
#   Rscript correlate_bact_fung.R --bact b.txt --fung f.txt --list-bact
#   Rscript correlate_bact_fung.R --bact b.txt --fung f.txt --list-fung
#
# No non-base packages are required.

## ---------- tiny argument parser ------------------------------------------
args <- commandArgs(trailingOnly = TRUE)
getopt <- function(flag, default = NULL) {
  i <- match(flag, args)
  if (is.na(i)) return(default)
  if (i == length(args)) return(TRUE)          # bare flag
  val <- args[i + 1]
  if (grepl("^--", val)) return(TRUE)          # bare flag followed by another
  val
}
hasflag <- function(flag) flag %in% args

bactfile  <- getopt("--bact")
fungfile  <- getopt("--fung")
mode      <- getopt("--mode")
fungal_q  <- getopt("--fungal")
bact_q    <- getopt("--bacterial")
method    <- tolower(getopt("--method", "pearson"))
adjust    <- getopt("--adjust", NULL)
min_prev  <- as.numeric(getopt("--min-prev", 3))
min_count <- as.numeric(getopt("--min-count", 10))
pseudoct  <- as.numeric(getopt("--pseudocount", 0.5))
matchmode <- tolower(getopt("--match", "exact"))
outfile   <- getopt("--out", NULL)
list_bact <- hasflag("--list-bact")
list_fung <- hasflag("--list-fung")

die <- function(...) { message("ERROR: ", ...); quit(status = 1) }
if (is.null(bactfile) || is.null(fungfile))
  die("--bact and --fung are both required.")
if (!file.exists(bactfile)) die("bacterial table not found: ", bactfile)
if (!file.exists(fungfile)) die("fungal table not found: ", fungfile)
if (!method %in% c("pearson", "spearman")) die("--method must be pearson or spearman")

## ---------- read a biom-style tsv (taxa x samples) ------------------------
# Handles a leading "# Constructed from biom file" comment line and a
# "#OTU ID" header line. Returns a numeric matrix, taxa in rows.
read_feature_table <- function(path) {
  lines <- readLines(path, warn = FALSE)
  # find header: first line starting with "#OTU ID", else first non-comment line
  hdr_i <- grep("^#OTU ID", lines)
  if (length(hdr_i) == 0) {
    nonc <- which(!grepl("^#", lines) & nzchar(lines))
    if (!length(nonc)) die("no header found in ", path)
    hdr_i <- nonc[1]
  } else hdr_i <- hdr_i[1]
  header <- strsplit(lines[hdr_i], "\t", fixed = TRUE)[[1]]
  samples <- header[-1]
  body <- lines[(hdr_i + 1):length(lines)]
  body <- body[nzchar(body)]
  body <- body[!grepl("^#", body)]
  sp <- strsplit(body, "\t", fixed = TRUE)
  taxa <- vapply(sp, function(x) x[1], character(1))
  mat <- t(vapply(sp, function(x) {
    v <- suppressWarnings(as.numeric(x[-1]))
    length(v) <- length(samples)            # pad short rows with NA
    v
  }, numeric(length(samples))))
  mat[is.na(mat)] <- 0
  rownames(mat) <- taxa
  colnames(mat) <- samples
  mat
}

bact <- read_feature_table(bactfile)
fung <- read_feature_table(fungfile)

if (list_bact) { cat(rownames(bact), sep = "\n"); quit(status = 0) }
if (list_fung) { cat(rownames(fung), sep = "\n"); quit(status = 0) }

if (is.null(mode)) die("--mode is required (f1b1 | f1ball | b1fall | allall).")
if (!mode %in% c("f1b1", "f1ball", "b1fall", "allall"))
  die("--mode must be one of f1b1, f1ball, b1fall, allall.")

## ---------- align to common samples ---------------------------------------
common <- intersect(colnames(bact), colnames(fung))
if (length(common) < 4)
  die("only ", length(common), " shared samples between the tables; ",
      "did you relabel the bacterial columns with the crosswalk first?")
bact <- bact[, common, drop = FALSE]
fung <- fung[, common, drop = FALSE]
message(sprintf("Common samples: %d", length(common)))

## ---------- covariates derived from dashed sample id ----------------------
# id form  E S 1 - t r   ->  biotype=E species=S cultivar=1 timepoint=t replicate=r
parse_covariates <- function(ids) {
  m <- regmatches(ids, regexec("^([EK])([A-Za-z])([0-9]+)-([0-9])([0-9])$", ids))
  ok <- vapply(m, length, integer(1)) == 6
  df <- data.frame(
    biotype   = NA_character_, species = NA_character_,
    cultivar  = NA_character_, timepoint = NA_character_,
    replicate = NA_character_, stringsAsFactors = FALSE)
  df <- df[rep(1, length(ids)), , drop = FALSE]
  rownames(df) <- ids
  for (i in which(ok)) {
    df$biotype[i]   <- m[[i]][2]; df$species[i]  <- m[[i]][3]
    df$cultivar[i]  <- m[[i]][4]; df$timepoint[i]<- m[[i]][5]
    df$replicate[i] <- m[[i]][6]
  }
  df
}
covar <- parse_covariates(common)

adj_vars <- character(0)
if (!is.null(adjust) && !isTRUE(adjust) && nzchar(adjust)) {
  adj_vars <- strsplit(adjust, ",")[[1]]
  adj_vars <- trimws(adj_vars)
  bad <- setdiff(adj_vars, colnames(covar))
  if (length(bad)) die("unknown --adjust covariate(s): ", paste(bad, collapse = ", "),
                       " (choose from biotype,species,cultivar,timepoint,replicate)")
  # drop covariates that failed to parse for any sample
  for (v in adj_vars)
    if (any(is.na(covar[[v]])))
      die("covariate '", v, "' could not be parsed from some sample ids; ",
          "cannot adjust for it.")
  message("Adjusting for covariates: ", paste(adj_vars, collapse = ", "))
}

## ---------- filter rare taxa + CLR transform ------------------------------
filter_taxa <- function(mat, min_prev, min_count) {
  keep <- rowSums(mat >= min_count) >= min_prev
  if (!any(keep)) die("all taxa removed by prevalence filter; loosen --min-prev/--min-count")
  mat[keep, , drop = FALSE]
}

# CLR per sample (column): log(x+pc) - mean over taxa of log(x+pc)
clr_transform <- function(mat, pc) {
  lg <- log(mat + pc)
  sweep(lg, 2, colMeans(lg), "-")
}

bact_f <- filter_taxa(bact, min_prev, min_count)
fung_f <- filter_taxa(fung, min_prev, min_count)
message(sprintf("Taxa kept after filtering: bacterial %d / %d, fungal %d / %d",
                nrow(bact_f), nrow(bact), nrow(fung_f), nrow(fung)))

bact_clr <- clr_transform(bact_f, pseudoct)
fung_clr <- clr_transform(fung_f, pseudoct)

## ---------- optional residualization for partial correlation --------------
# Replace each taxon's CLR vector with residuals after regressing on covars.
residualize <- function(clrmat, covdf, vars) {
  if (!length(vars)) return(clrmat)
  rhs <- paste(sprintf("factor(%s)", vars), collapse = " + ")
  form <- as.formula(paste("y ~", rhs))
  out <- clrmat
  for (i in seq_len(nrow(clrmat))) {
    d <- cbind(data.frame(y = clrmat[i, ]), covdf)
    fit <- lm(form, data = d)
    out[i, ] <- residuals(fit)
  }
  out
}
bact_use <- residualize(bact_clr, covar, adj_vars)
fung_use <- residualize(fung_clr, covar, adj_vars)

## ---------- taxon lookup --------------------------------------------------
find_taxon <- function(query, taxa, which) {
  if (is.null(query) || isTRUE(query)) die("--", which, " taxon is required for this mode.")
  if (matchmode == "exact") {
    if (query %in% taxa) return(query)
    die("exact ", which, " taxon not found: '", query,
        "'. Use --list-", substr(which,1,4), " to see labels, or --match substr.")
  } else {
    hits <- taxa[grepl(query, taxa, fixed = TRUE)]
    if (!length(hits)) die("no ", which, " taxon matches substring '", query, "'.")
    if (length(hits) > 1)
      die("substring '", query, "' matched ", length(hits), " ", which,
          " taxa; be more specific:\n  ", paste(head(hits, 10), collapse = "\n  "))
    return(hits[1])
  }
}

## ---------- correlation engine --------------------------------------------
corr_one <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  n <- sum(ok)
  if (n < 4 || sd(x[ok]) == 0 || sd(y[ok]) == 0)
    return(c(estimate = NA, p.value = NA, n = n))
  ct <- suppressWarnings(cor.test(x[ok], y[ok], method = method))
  c(estimate = unname(ct$estimate), p.value = ct$p.value, n = n)
}

## ---------- run the requested mode ----------------------------------------
results <- NULL
if (mode == "f1b1") {
  ft <- find_taxon(fungal_q, rownames(fung_use), "fungal")
  bt <- find_taxon(bact_q,   rownames(bact_use), "bacterial")
  r <- corr_one(fung_use[ft, ], bact_use[bt, ])
  results <- data.frame(fungal = ft, bacterial = bt,
                        n = r["n"], estimate = r["estimate"],
                        p_value = r["p.value"], stringsAsFactors = FALSE)
} else if (mode == "f1ball") {
  ft <- find_taxon(fungal_q, rownames(fung_use), "fungal")
  fy <- fung_use[ft, ]
  rr <- t(apply(bact_use, 1, function(bx) corr_one(fy, bx)))
  results <- data.frame(fungal = ft, bacterial = rownames(bact_use),
                        n = rr[, "n"], estimate = rr[, "estimate"],
                        p_value = rr[, "p.value"], stringsAsFactors = FALSE)
} else if (mode == "b1fall") {
  bt <- find_taxon(bact_q, rownames(bact_use), "bacterial")
  bx <- bact_use[bt, ]
  rr <- t(apply(fung_use, 1, function(fy) corr_one(bx, fy)))
  results <- data.frame(fungal = rownames(fung_use), bacterial = bt,
                        n = rr[, "n"], estimate = rr[, "estimate"],
                        p_value = rr[, "p.value"], stringsAsFactors = FALSE)
} else { # allall: every fungal x every bacterial
  combos <- expand.grid(fi = seq_len(nrow(fung_use)), bi = seq_len(nrow(bact_use)))
  message(sprintf("Testing %d fungal x %d bacterial = %d pairs ...",
                  nrow(fung_use), nrow(bact_use), nrow(combos)))
  rr <- mapply(function(fi, bi) corr_one(fung_use[fi, ], bact_use[bi, ]),
               combos$fi, combos$bi)
  results <- data.frame(fungal = rownames(fung_use)[combos$fi],
                        bacterial = rownames(bact_use)[combos$bi],
                        n = rr["n", ], estimate = rr["estimate", ],
                        p_value = rr["p.value", ], stringsAsFactors = FALSE)
}

# BH-FDR across the tested set (single test in f1b1 => p_adj == p_value)
results$p_adj <- p.adjust(results$p_value, method = "BH")
results$method <- method
results$adjusted_for <- if (length(adj_vars)) paste(adj_vars, collapse = "+") else "none"

# order most-significant first for the "all" modes
if (mode != "f1b1")
  results <- results[order(results$p_value, -abs(results$estimate)), ]

## ---------- output --------------------------------------------------------
fmt <- results
fmt$estimate <- signif(fmt$estimate, 4)
fmt$p_value  <- signif(fmt$p_value, 4)
fmt$p_adj    <- signif(fmt$p_adj, 4)

if (!is.null(outfile) && !isTRUE(outfile)) {
  write.table(fmt, outfile, sep = "\t", quote = FALSE, row.names = FALSE)
  message("Wrote ", nrow(fmt), " row(s) to ", outfile)
}
# always echo a preview
print(utils::head(fmt, 25), row.names = FALSE)
if (nrow(fmt) > 25) message("... (", nrow(fmt) - 25, " more rows; see --out file)")
