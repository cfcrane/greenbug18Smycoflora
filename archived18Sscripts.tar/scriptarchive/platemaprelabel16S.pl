#!/usr/bin/perl
# platemaprelabel16S.pl
#
# Relabel the sample columns of the bacterial 16S feature table
# (gbmultihost16SgenerawithoutBuchnera.txt) from the plate/well/treatment
# format "16sP<plate>_<row><col>_<treatment>" (e.g. 16sP2_A3_ER2) to the
# biotype-species-cultivar-timepoint-replicate dashed code (e.g. ER2-11)
# taken from the plate map (PlateMap16samplicons.txt), and collapse the
# table to one row per genus by SUMMING the counts of every input row that
# shares a genus label, within each column.
#
# Counts are combined over plates and wells (the plate/well coordinate is
# dissolved into the treatment+timepoint+replicate code) and over duplicate
# genus rows, but kept separate for every individual sample (treatment x
# timepoint x replicate) and for every distinct genus.
#
# Usage:
#   perl platemaprelabel16S.pl <PlateMap16samplicons.txt> <16S_table.txt> > out.txt
#
# Plate map format:
#   - One section per plate, introduced by a line matching "DNA plate <N>".
#   - Within a section, the 8 data rows begin with a single letter A-H,
#     followed by 12 tab-separated cells (columns 1-12).  Each non-empty cell
#     holds a dashed code like ER2-31 (possibly with stray trailing spaces).
#   - Note/annotation lines (e.g. "16s foil broken", "no backup") are ignored
#     because their first field is not a bare A-H row letter.
#
# Table format:
#   - Optional leading "# Constructed from biom file" comment line is skipped.
#   - Header line: first field is the genus-label column ("OTU ID" or
#     "#OTU ID"); remaining fields are sample columns "16sP<plate>_<well>_<trt>".
#   - Data lines: first field is the genus label; remaining fields are counts
#     (integer-valued floats such as "1422.0").  Several rows may share a
#     genus label and are summed together.
#
# Diagnostics (unmapped wells, treatment/plate-map mismatches, duplicate
# output codes, summary counts) are written to STDERR.

use strict;
use warnings;

die "Usage: perl platemaprelabel16S.pl <platemap.txt> <16S_table.txt> > out.txt\n"
    unless @ARGV == 2;

my ($mapfile, $tablefile) = @ARGV;

# ---- 1. parse the plate map ----------------------------------------------
# %cell{ "plate|row|col" } = dashed code
my %cell;
open(my $M, '<', $mapfile) or die "Cannot open plate map '$mapfile': $!\n";
my $plate;
while (my $line = <$M>) {
    $line =~ s/\r?\n$//;
    if ($line =~ /DNA\s+plate\s+(\d+)/i) { $plate = $1; next; }
    my @f = split /\t/, $line, -1;
    next unless @f;
    (my $row = defined $f[0] ? $f[0] : '') =~ s/^\s+|\s+$//g;
    next unless $row =~ /^[A-H]$/;            # only the 8 well rows
    next unless defined $plate;               # rows before any plate header
    for my $col (1 .. 12) {
        my $code = defined $f[$col] ? $f[$col] : '';
        $code =~ s/^\s+|\s+$//g;
        next if $code eq '';                  # empty well
        $cell{"$plate|$row|$col"} = $code;
    }
}
close $M;
die "No wells parsed from plate map '$mapfile'\n" unless %cell;

# ---- 2. read the table header and build the new column names --------------
open(my $T, '<', $tablefile) or die "Cannot open table '$tablefile': $!\n";

my $header;
while (my $line = <$T>) {
    $line =~ s/\r?\n$//;
    next if $line =~ /^# Constructed from biom/i;   # leading biom comment
    next if $line =~ /^\s*$/;
    $header = $line; last;
}
die "Could not find a header row in '$tablefile'\n" unless defined $header;

my @hcols   = split /\t/, $header, -1;
my $idname  = shift @hcols;                   # genus-label column header
my @newhead;                                  # relabeled sample headers
my %seen;                                     # detect duplicate output codes
for my $name (@hcols) {
    if ($name =~ /^16sP(\d+)_([A-H])(\d+)_(.+)$/) {
        my ($p, $r, $c, $trt) = ($1, $2, $3, $4);
        my $code = $cell{"$p|$r|$c"};
        if (defined $code) {
            (my $prefix = $code) =~ s/-.*$//;
            warn "Treatment mismatch for column '$name': table says '$trt' but plate map cell is '$code'.\n"
                if $prefix ne $trt;
            warn "Duplicate output code '$code' (from column '$name').\n" if $seen{$code}++;
            push @newhead, $code;
        } else {
            warn "No plate-map cell for column '$name' (plate $p, well $r$c); keeping original name.\n";
            push @newhead, $name;
        }
    } else {
        warn "Column '$name' does not match 16sP<plate>_<well>_<treatment>; keeping original name.\n";
        push @newhead, $name;
    }
}
my $ncol = scalar @newhead;

# ---- 3. read data rows, summing counts per genus per column ---------------
my @order;                                    # genus labels, first-seen order
my %sum;                                       # genus -> arrayref of column sums
while (my $line = <$T>) {
    $line =~ s/\r?\n$//;
    next if $line =~ /^\s*$/;
    my @f = split /\t/, $line, -1;
    my $genus = shift @f;
    unless (exists $sum{$genus}) {
        push @order, $genus;
        $sum{$genus} = [ (0) x $ncol ];
    }
    my $row = $sum{$genus};
    for my $i (0 .. $ncol - 1) {
        my $v = defined $f[$i] ? $f[$i] : '';
        $v =~ s/^\s+|\s+$//g;
        next if $v eq '';
        if ($v =~ /^-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?$/) {
            $row->[$i] += $v;
        } else {
            warn "Non-numeric value '$v' for genus '$genus' in column ", $i + 1, "; treated as 0.\n";
        }
    }
}
close $T;

# ---- 4. emit the relabeled, genus-summed table ----------------------------
print join("\t", $idname, @newhead), "\n";
for my $genus (@order) {
    my @out = map {
        my $s = $_;
        ($s == int($s)) ? sprintf("%.0f", $s) : $s;   # integer counts stay integer
    } @{ $sum{$genus} };
    print join("\t", $genus, @out), "\n";
}

warn sprintf("Wrote %d genera x %d samples.\n", scalar(@order), $ncol);
