## Sorted relative-abundance ("frequency") plots for selected fungal genera.
##
## Figure 1: Hannaella, Fusarium, Mortierella+Mortierellaceae, Papiliotrema,
##           Simplicillium -- each on its own panel, samples sorted in
##           ascending order independently within each panel (reveals the
##           shape of each taxon's own distribution: smooth ramp vs.
##           bimodal "few high, most near zero" step).
##
## Figure 2: Fusarium, sorted ascending, fixes the sample order; Papiliotrema
##           and Simplicillium are then plotted in that SAME (Fusarium-
##           determined) sample order without re-sorting -- a visual test of
##           whether their high/low samples coincide with Fusarium's.

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

## Same merge used throughout this session
merged <- colSums(counts[c("Mortierella", "Mortierellaceae"), ])
counts <- counts[!(rownames(counts) %in% c("Mortierella", "Mortierellaceae")), ]
counts <- rbind(counts, "Mortierella+Mortierellaceae" = merged)

sample_totals <- colSums(counts)
relabund_pct <- sweep(counts, 2, sample_totals, "/") * 100

get_taxon <- function(g) as.numeric(relabund_pct[g, ])

taxa5 <- c("Hannaella", "Fusarium", "Mortierella+Mortierellaceae",
           "Papiliotrema", "Simplicillium")

## ---------------------------------------------------------------------
## Figure 1: 5 panels, each independently sorted ascending
## ---------------------------------------------------------------------
plot_fig1 <- function() {
  par(mfrow = c(5, 1), mar = c(3.2, 4.2, 2, 1.2), oma = c(2, 0, 0.5, 0))
  line_col <- "#2a78d6"
  for (g in taxa5) {
    y <- sort(get_taxon(g))
    n <- length(y)
    plot(seq_len(n), y, type = "l", lwd = 1.8, col = line_col,
         xlab = "", ylab = "Rel. abund. (%)",
         main = g, font.main = 3, cex.main = 1.05,
         las = 1, bty = "l")
  }
  mtext("Sample rank (ascending within taxon)", side = 1, outer = TRUE, line = 0.5)
}

pdf("gb18Sgenusfreq_5taxa_sorted.pdf", width = 6.5, height = 11)
plot_fig1()
dev.off()

svg("gb18Sgenusfreq_5taxa_sorted.svg", width = 6.5, height = 11)
plot_fig1()
dev.off()

png("gb18Sgenusfreq_5taxa_sorted.png", width = 6.5, height = 11, units = "in", res = 600)
plot_fig1()
dev.off()

## ---------------------------------------------------------------------
## Figure 2: order fixed by Fusarium (ascending); Papiliotrema and
## Simplicillium plotted in that same sample order, unsorted themselves
## ---------------------------------------------------------------------
fus <- get_taxon("Fusarium")
ord <- order(fus)  # sample order that sorts Fusarium ascending

fus_sorted  <- fus[ord]
pap_in_ord  <- get_taxon("Papiliotrema")[ord]
simp_in_ord <- get_taxon("Simplicillium")[ord]

n <- length(fus_sorted)
ymax <- max(fus_sorted, pap_in_ord, simp_in_ord)

col_fus  <- "#2a78d6"  # blue  -- categorical slot 1
col_pap  <- "#1baf7a"  # aqua  -- categorical slot 2
col_simp <- "#eda100"  # yellow -- categorical slot 3

plot_fig2 <- function() {
  par(mar = c(4.2, 4.2, 2, 1.2))
  plot(seq_len(n), fus_sorted, type = "l", lwd = 2, col = col_fus,
       ylim = c(0, ymax), las = 1, bty = "l",
       xlab = "Sample rank (ascending by Fusarium abundance)",
       ylab = "Relative abundance (%)",
       main = "Fusarium-ordered comparison")
  lines(seq_len(n), pap_in_ord, lwd = 1.8, col = col_pap, lty = 2)
  lines(seq_len(n), simp_in_ord, lwd = 1.8, col = col_simp, lty = 3)
  legend("topleft", legend = c("Fusarium", "Papiliotrema", "Simplicillium"),
         col = c(col_fus, col_pap, col_simp), lty = c(1, 2, 3), lwd = 2,
         text.col = "black", bty = "n", cex = 0.9)
}

pdf("gb18Sgenusfreq_fusariumorder_3taxa.pdf", width = 7, height = 5)
plot_fig2()
dev.off()

svg("gb18Sgenusfreq_fusariumorder_3taxa.svg", width = 7, height = 5)
plot_fig2()
dev.off()

## ---------------------------------------------------------------------
## Figure 3: same Fusarium-ordered comparison, with Mortierella+
## Mortierellaceae in place of Papiliotrema/Simplicillium
## ---------------------------------------------------------------------
mort_in_ord <- get_taxon("Mortierella+Mortierellaceae")[ord]
ymax3 <- max(fus_sorted, mort_in_ord)

col_mort <- "#1baf7a"  # aqua -- categorical slot 2

plot_fig3 <- function() {
  par(mar = c(4.2, 4.2, 2, 1.2))
  plot(seq_len(n), fus_sorted, type = "l", lwd = 2, col = col_fus,
       ylim = c(0, ymax3), las = 1, bty = "l",
       xlab = "Sample rank (ascending by Fusarium abundance)",
       ylab = "Relative abundance (%)",
       main = "Fusarium-ordered comparison")
  lines(seq_len(n), mort_in_ord, lwd = 1.8, col = col_mort, lty = 2)
  legend("topleft", legend = c("Fusarium", "Mortierella+Mortierellaceae"),
         col = c(col_fus, col_mort), lty = c(1, 2), lwd = 2,
         text.col = "black", bty = "n", cex = 0.9)
}

pdf("gb18Sgenusfreq_fusariumorder_mortierella.pdf", width = 7, height = 5)
plot_fig3()
dev.off()

svg("gb18Sgenusfreq_fusariumorder_mortierella.svg", width = 7, height = 5)
plot_fig3()
dev.off()

## ---------------------------------------------------------------------
## Figure 1b: same 5 panels, but each point rendered as a filled bar
## colored by biotype (E vs K), so the biotype composition of the
## high-abundance tail is visible directly on the sorted curve.
## ---------------------------------------------------------------------
meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE,
                        stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
biotype <- factor(meta_raw[common_ids, "biotype"])
names(biotype) <- common_ids

col_E <- "#2a78d6"  # blue -- categorical slot 1
col_K <- "#1baf7a"  # aqua -- categorical slot 2

## Panel order for this figure only: Papiliotrema moved up under Hannaella,
## Mortierella+Mortierellaceae moved to the bottom.
taxa5_bybiotype <- c("Hannaella", "Papiliotrema", "Fusarium", "Simplicillium",
                     "Mortierella+Mortierellaceae")

plot_fig1_bybiotype <- function() {
  par(mfrow = c(5, 1), mar = c(3.2, 4.2, 2, 1.2), oma = c(2, 0, 0.5, 0))
  for (i in seq_along(taxa5_bybiotype)) {
    g <- taxa5_bybiotype[i]
    y <- setNames(as.numeric(relabund_pct[g, common_ids]), common_ids)
    ord <- order(y)
    y_sorted <- y[ord]
    bt_sorted <- biotype[ord]
    n <- length(y_sorted)
    bar_col <- ifelse(bt_sorted == "E", col_E, col_K)

    plot(seq_len(n), y_sorted, type = "n",
         xlab = "", ylab = "Rel. abund. (%)",
         main = g, font.main = 3, cex.main = 1.05,
         las = 1, bty = "l")
    rect(seq_len(n) - 0.5, 0, seq_len(n) + 0.5, y_sorted,
         col = bar_col, border = NA)

    if (i == 1) {
      legend("topleft", legend = c("Biotype E", "Biotype K"),
             fill = c(col_E, col_K), text.col = "black", bty = "n", cex = 0.9)
    }
  }
  mtext("Sample rank (ascending within taxon)", side = 1, outer = TRUE, line = 0.5)
}

pdf("gb18Sgenusfreq_5taxa_sorted_bybiotype.pdf", width = 6.5, height = 11)
plot_fig1_bybiotype()
dev.off()

svg("gb18Sgenusfreq_5taxa_sorted_bybiotype.svg", width = 6.5, height = 11)
plot_fig1_bybiotype()
dev.off()

png("gb18Sgenusfreq_5taxa_sorted_bybiotype.png", width = 6.5, height = 11, units = "in", res = 600)
plot_fig1_bybiotype()
dev.off()

## ---------------------------------------------------------------------
## Figure 4: the two Fusarium-ordered comparison plots (Figures 2 and 3)
## combined as two stacked panels on one page.
## ---------------------------------------------------------------------
plot_fig_combined <- function() {
  par(mfrow = c(2, 1))
  plot_fig2()
  plot_fig3()
}

pdf("gb18Sgenusfreq_fusariumorder_combined.pdf", width = 7, height = 9.5)
plot_fig_combined()
dev.off()

svg("gb18Sgenusfreq_fusariumorder_combined.svg", width = 7, height = 9.5)
plot_fig_combined()
dev.off()

png("gb18Sgenusfreq_fusariumorder_combined.png", width = 7, height = 9.5, units = "in", res = 600)
plot_fig_combined()
dev.off()

cat("Written:\n",
    "  gb18Sgenusfreq_5taxa_sorted.pdf / .svg\n",
    "  gb18Sgenusfreq_fusariumorder_3taxa.pdf / .svg\n",
    "  gb18Sgenusfreq_fusariumorder_mortierella.pdf / .svg\n",
    "  gb18Sgenusfreq_5taxa_sorted_bybiotype.pdf / .svg\n",
    "  gb18Sgenusfreq_fusariumorder_combined.pdf / .svg\n")
