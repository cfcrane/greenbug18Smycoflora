## ANCOM-BC2 differential abundance of fungal genera by timepoint,
## run SEPARATELY within biotype E and biotype K -- parallel to the
## whole-dataset ancombc timepoint analysis already published as
## gb18Sqfildeblurredcounts1119mcraref25750_ancombcbarplots.svg (panels B-D:
## "first/second/third timepoint" = t2/t4/t8 vs. t0 reference), and parallel
## to this session's biotype-stratified KW/WGCNA reruns.
##
## Genus table is used UNMERGED (Mortierella and Mortierellaceae kept
## separate) to match the taxonomy used in the existing published figure.

suppressMessages(library(ANCOMBC))

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE,
                        stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
counts <- counts[, common_ids]
meta <- meta_raw[common_ids, ]
meta$timepoint <- factor(meta$timepoint, levels = c("t0", "t2", "t4", "t8"))
meta$biotype   <- factor(meta$biotype)

run_ancombc_for_biotype <- function(bt) {
  cat("\n============================================================\n")
  cat("Biotype", bt, "\n")
  cat("============================================================\n")

  ids <- rownames(meta)[meta$biotype == bt]
  mat <- as.matrix(counts[, ids])
  md  <- meta[ids, , drop = FALSE]
  md$timepoint <- droplevels(md$timepoint)

  cat("Samples:", ncol(mat), "  Cell sizes:\n")
  print(table(md$timepoint))

  out <- ancombc2(
    data = mat, taxa_are_rows = TRUE, meta_data = md,
    fix_formula = "timepoint", p_adj_method = "BH",
    prv_cut = 0.10, lib_cut = 0, group = "timepoint",
    struc_zero = TRUE, neg_lb = TRUE, alpha = 0.05,
    n_cl = 8, verbose = FALSE
  )

  saveRDS(out, paste0("gb18Sfungancombc_biotype", bt, "_timepoint.rds"))
  invisible(out)
}

resE <- run_ancombc_for_biotype("E")
resK <- run_ancombc_for_biotype("K")

cat("\nDone. Saved gb18Sfungancombc_biotypeE_timepoint.rds and gb18Sfungancombc_biotypeK_timepoint.rds\n")
