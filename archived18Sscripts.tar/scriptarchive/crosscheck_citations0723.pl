#!/usr/bin/perl
## Cross-check in-text citations (extracted the same way as
## extract_citations0723.pl) against the manuscript's own References list in
## both directions: in-text citations with no matching bibliography entry,
## and bibliography entries never cited in text.
##
## Matching strategy: for each in-text citation, take its FIRST author's
## surname plus year (e.g. "Kruskal"/"1952" out of "Kruskal and Wallis
## (1952)") and search each References *entry* (a blank-line-delimited
## paragraph) for that surname and year both appearing in it. Matching only
## on the first author (not every co-author) avoids false "missing" reports
## from second-author spelling/accent differences between in-text and
## bibliography (e.g. in-text "Barta and Cagan (2006)" vs bibliography
## "Barta, M. and Cagáň, L. (2006)" -- still matches on "Barta"+"2006").
## Both sides are diacritic- and apostrophe-folded before comparing (e.g.
## "González-Román" folds to the same form as in-text "Gonzalez-Roman";
## curly "O’Donnell" folds the same as straight "O'Donnell").
##
## Usage: perl crosscheck_citations0723.pl <input_file> [stopword]
##   stopword defaults to "References" if omitted -- same meaning as in
##   extract_citations0723.pl (where in-text-citation collection stops),
##   and also marks where the References list itself begins.

use strict;
use warnings;
use utf8;
use open ':std', ':encoding(UTF-8)';
use Unicode::Normalize qw(NFKD);

my ($infile, $stopword) = @ARGV;
die "Usage: perl crosscheck_citations0723.pl <input_file> [stopword]\n"
    unless defined $infile;
$stopword = 'References' unless defined $stopword;

open(my $fh, '<:encoding(UTF-8)', $infile) or die "Cannot open $infile: $!\n";

my $NAME     = qr/[A-Z][A-Za-z'\x{2019}\-]+/;
my $YEAR     = qr/\d{4}[a-z]?/;
my $YEARLIST = qr/$YEAR(?:(?:,\s*|\s+and\s+)$YEAR)*/;
my $AND      = qr/(?:and|&)/;

my %seen;
my @citations;   # { display => "...", name => first-author-surname, year => "2025a" }

sub record_years {
    my ($display_who, $search_name, $yearlist) = @_;
    for my $year (split /\s*(?:,|and)\s*/, $yearlist) {
        next unless length $year;
        my $key = "$display_who ($year)";
        next if $seen{$key}++;
        push @citations, { display => $key, name => $search_name, year => $year };
    }
}

LINE: while (my $line = <$fh>) {
    chomp $line;
    (my $trimmed = $line) =~ s/^\s+|\s+$//g;
    last LINE if $trimmed eq $stopword;

    ## ---- Pass A: narrative citations ----
    while ($line =~ m{
        ($NAME) \s+ et\ al\.? \s* \( ($YEARLIST) \)
      | ($NAME) \s+ $AND \s+ ($NAME) \s* \( ($YEARLIST) \)
      | ($NAME) \s* \( ($YEARLIST) \)
    }gx) {
        if (defined $1) {
            record_years("$1 et al.", $1, $2);
        } elsif (defined $3) {
            record_years("$3 and $4", $3, $5);
        } elsif (defined $6) {
            record_years($6, $6, $7);
        }
    }

    ## ---- Pass B: parenthetical citation clusters ----
    while ($line =~ /\(([^()]*)\)/g) {
        my $interior = $1;
        for my $segment (split /;\s*/, $interior) {
            if ($segment =~ /($NAME)\s+et\s+al\.?,?\s*($YEARLIST)/) {
                record_years("$1 et al.", $1, $2);
            } elsif ($segment =~ /($NAME)\s+$AND\s+($NAME),\s*($YEARLIST)/) {
                record_years("$1 and $2", $1, $3);
            } elsif ($segment =~ /($NAME),\s*($YEARLIST)/) {
                record_years($1, $1, $2);
            }
        }
    }
}

## ---- Read the rest of the file (the References list itself) as
## blank-line-delimited entries, stopping at "List of Figures" if present ----
my @entries;
{
    local $/ = "";
    while (my $para = <$fh>) {
        last if $para =~ /^\s*List of Figures/m;
        $para =~ s/\s+/ /g;
        $para =~ s/^\s+|\s+$//g;
        push @entries, $para if length $para;
    }
}
close $fh;

die "No References entries found after the '$stopword' line -- check the stopword.\n"
    unless @entries;

sub fold_text {
    my ($s) = @_;
    $s = NFKD($s);
    $s =~ s/\p{NonspacingMark}//g;
    $s =~ s/['\x{2019}]//g;
    return $s;
}

my @folded_entries = map { fold_text($_) } @entries;
my @entry_cited    = (0) x @entries;   # marked true if any in-text citation matches it

## Short "Author(s) (Year)" header for each entry, for display purposes only
## -- everything up through the first "(Year)" it contains.
my @entry_headers = map {
    /^(.*?\(\d{4}[a-z]?\))/ ? $1 : (length($_) > 70 ? substr($_, 0, 70) . '...' : $_)
} @entries;

my @missing;
for my $c (@citations) {
    my $fname = fold_text($c->{name});
    my $found = 0;
    for my $i (0 .. $#folded_entries) {
        if ($folded_entries[$i] =~ /\b\Q$fname\E\b/ && $folded_entries[$i] =~ /\b\Q$c->{year}\E\b/) {
            $found = 1;
            $entry_cited[$i] = 1;
            ## keep scanning (don't 'last') so every matching entry gets
            ## credited -- relevant when two References entries share both
            ## the same first-author surname and year (rare, but possible)
        }
    }
    push @missing, $c->{display} unless $found;
}

my @uncited = map { $entry_headers[$_] } grep { !$entry_cited[$_] } 0 .. $#entries;

printf "%d in-text citation(s) checked against %d References entries.\n",
    scalar(@citations), scalar(@entries);
printf "%d citations matched, %d with no matching References entry.\n",
    scalar(@citations) - scalar(@missing), scalar(@missing);
printf "%d References entries cited at least once, %d never cited in text.\n\n",
    scalar(@entries) - scalar(@uncited), scalar(@uncited);

if (@missing) {
    print "In-text citations missing from References list:\n";
    print "  $_\n" for sort @missing;
} else {
    print "All in-text citations have a matching References entry.\n";
}

print "\n";

if (@uncited) {
    print "References entries never cited in text:\n";
    print "  $_\n" for sort @uncited;
} else {
    print "All References entries are cited at least once in text.\n";
}
