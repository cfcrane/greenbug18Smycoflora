## Genus-level Kruskal-Wallis tests by biotype and by timepoint,
## for all genera in the fungal (18S) genus abundance table.
## Mirrors the KW + BH-correction convention used in runbenjhoch0107a.R,
## but applied per-genus instead of per-alpha-diversity-metric.

counts <- read.delim("fung_genus_forbiom.txt", check.names = FALSE, row.names = 1)

## Merge Mortierella (genus-level assignment) with Mortierellaceae
## (family-level Incertae sedis assignment of the same fungal group)
## into a single combined taxon before testing.
merged <- colSums(counts[c("Mortierella", "Mortierellaceae"), ])
counts <- counts[!(rownames(counts) %in% c("Mortierella", "Mortierellaceae")), ]
counts <- rbind(counts, "Mortierella+Mortierellaceae" = merged)

meta_raw <- read.delim("gb18Sshannonkwrawdata.txt", check.names = FALSE,
                        stringsAsFactors = FALSE)
meta_raw <- meta_raw[-1, ]  # drop the "#q2:types" row
rownames(meta_raw) <- meta_raw$id

common_ids <- intersect(colnames(counts), rownames(meta_raw))
cat("Samples in genus table:", ncol(counts), "\n")
cat("Samples in metadata:   ", nrow(meta_raw), "\n")
cat("Samples used (intersection):", length(common_ids), "\n\n")

counts <- counts[, common_ids]
meta <- meta_raw[common_ids, ]
meta$biotype   <- factor(meta$biotype)
meta$timepoint <- factor(meta$timepoint)

sample_totals <- colSums(counts)
relabund <- sweep(counts, 2, sample_totals, "/")

genera <- rownames(relabund)
n <- length(genera)

H_bt <- p_bt <- H_tp <- p_tp <- rep(NA_real_, n)

for (i in seq_len(n)) {
  x <- as.numeric(relabund[i, ])

  bt <- tryCatch(kruskal.test(x ~ meta$biotype), error = function(e) NULL)
  if (!is.null(bt)) { H_bt[i] <- unname(bt$statistic); p_bt[i] <- bt$p.value }

  tp <- tryCatch(kruskal.test(x ~ meta$timepoint), error = function(e) NULL)
  if (!is.null(tp)) { H_tp[i] <- unname(tp$statistic); p_tp[i] <- tp$p.value }
}

q_bt <- p.adjust(p_bt, method = "BH")
q_tp <- p.adjust(p_tp, method = "BH")

res_biotype <- data.frame(genus = genera, H = H_bt, p_value = p_bt, q_value = q_bt)
res_timepoint <- data.frame(genus = genera, H = H_tp, p_value = p_tp, q_value = q_tp)

res_biotype   <- res_biotype[order(res_biotype$q_value), ]
res_timepoint <- res_timepoint[order(res_timepoint$q_value), ]

write.table(res_biotype, "gb18Sgenuskruskalbiotype.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(res_timepoint, "gb18Sgenuskruskaltimepoint.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)

cat("Biotype test:   ", sum(q_bt < 0.05, na.rm = TRUE), "of", n, "genera significant at q < 0.05\n")
cat("Timepoint test: ", sum(q_tp < 0.05, na.rm = TRUE), "of", n, "genera significant at q < 0.05\n\n")

cat("Top 15 genera by biotype q-value:\n")
print(head(res_biotype, 15), row.names = FALSE)

cat("\nTop 15 genera by timepoint q-value:\n")
print(head(res_timepoint, 15), row.names = FALSE)
