## Relative frequency of the 10 most abundant genera in each replicate of
## EW0 (E biotype, wheat/Newton, t0: EW1-01, EW1-02, EW1-03) and KW0 (K
## biotype, wheat/Newton, t0: KW1-01, KW1-02, KW1-03), plus the summed
## relative frequency of all remaining ("other") genera in that replicate.
##
## "EW0"/"KW0" correspond to metadata `group` values EW1_0 / KW1_0 in
## metadataforbiotypeE0715.txt / metadataforbiotypeK0715.txt -- each has
## exactly 3 replicates (suffix -01, -02, -03).
##
## For each replicate, relative frequency = raw genus count / that
## replicate's total count (colSum), independent of the other replicates --
## no rarefaction, since this is a simple per-sample composition summary,
## not a distance-based test. Output is long-format (one row per
## replicate x rank) since the top-10 genus set can differ across
## replicates.

## ---- CONFIG ----
counts_file   <- "../fung_genus_forbiom.txt"
replicates    <- c("EW1-01", "EW1-02", "EW1-03", "KW1-01", "KW1-02", "KW1-03")
n_top         <- 10
out_file      <- "relfreq_top10_EW0_KW0_0723.txt"
## -----------------

counts <- read.delim(counts_file, check.names = FALSE, row.names = 1)
missing <- setdiff(replicates, colnames(counts))
if (length(missing) > 0) {
  stop("Replicate(s) not found in ", counts_file, ": ", paste(missing, collapse = ", "))
}

counts <- counts[, replicates, drop = FALSE]
cat(sprintf("Loaded %d genera x %d replicates: %s\n",
            nrow(counts), ncol(counts), paste(replicates, collapse = ", ")))

relfreq <- sweep(counts, 2, colSums(counts), "/")

rows <- lapply(replicates, function(r) {
  ord <- order(relfreq[[r]], decreasing = TRUE)
  v <- relfreq[[r]][ord]
  genus <- rownames(relfreq)[ord]
  top <- data.frame(replicate = r, rank = seq_len(n_top),
                     genus = genus[seq_len(n_top)], rel_freq = v[seq_len(n_top)],
                     stringsAsFactors = FALSE)
  other <- data.frame(replicate = r, rank = n_top + 1,
                       genus = sprintf("Other (%d rarer genera)", length(v) - n_top),
                       rel_freq = sum(v[-seq_len(n_top)]),
                       stringsAsFactors = FALSE)
  rbind(top, other)
})
result <- do.call(rbind, rows)

write.table(result, out_file, sep = "\t", quote = FALSE, row.names = FALSE)
cat("Written:", out_file, "\n")
print(result)
